﻿$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$settingsPath = Join-Path $root 'settings.json'
$engineDir = $root
if (Test-Path -LiteralPath $settingsPath) {
    try {
        $sc = Get-Content -LiteralPath $settingsPath -Raw -Encoding UTF8 | ConvertFrom-Json
        $ee = ''
        if ($null -ne $sc.PSObject.Properties['engineExe']) { $ee = [string]$sc.engineExe }
        if ($ee -ne '' -and (Test-Path -LiteralPath $ee)) {
            $engineDir = [IO.Path]::GetDirectoryName($ee)
        }
    } catch { }
}
$exe = Join-Path $engineDir 'llama-server.exe'

function Get-LocalBuild {
    if (-not (Test-Path $exe)) { return 0 }
    $oldEap = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    $v = ''
    try { $v = (& $exe --version 2>&1 | Out-String) } catch { $v = '' }
    if ([string]::IsNullOrWhiteSpace($v)) {
        try { $v = (& $exe -h 2>&1 | Out-String) } catch { $v = '' }
    }
    $ErrorActionPreference = $oldEap
    if ($v -match 'build[:\s]+(\d{3,6})') { return [int]$Matches[1] }
    if ($v -match 'b(\d{3,6})-') { return [int]$Matches[1] }
    if ($v -match '\(build\s+(\d+)\)') { return [int]$Matches[1] }
    return 0
}

Write-Host ''
Write-Host '== 检查 llama.cpp 更新 ==' -ForegroundColor Cyan
$local = Get-LocalBuild
Write-Host ("当前版本: build {0}" -f $local)

Write-Host '正在查询 GitHub 最新构建 ...'
try {
    $rels = Invoke-RestMethod 'https://api.github.com/repos/ggml-org/llama.cpp/releases?per_page=10' -Headers @{ 'User-Agent' = 'llama-updater' } -TimeoutSec 60
} catch {
    Write-Host ('查询失败: ' + $_.Exception.Message) -ForegroundColor Red
    Write-Host '（可能是网络代理问题，可稍后重试）'
    Read-Host '按 Enter 关闭'; exit 1
}

$rel = $rels | Where-Object { $_.tag_name -match '^b\d+$' } | Select-Object -First 1
if (-not $rel) { Write-Host '没有找到构建版本。' -ForegroundColor Red; Read-Host '按 Enter 关闭'; exit 1 }
$latest = [int]($rel.tag_name.Substring(1))
Write-Host ("最新版本: build {0}" -f $latest)

if ($latest -le $local) {
    Write-Host '已经是最新版本，无需更新。' -ForegroundColor Green
    Read-Host '按 Enter 关闭'; exit 0
}

$asset = $rel.assets | Where-Object { $_.name -match '^llama-b[0-9]+-bin-win-cuda-13\.[0-9]+-x64\.zip$' } | Select-Object -First 1
if (-not $asset) { Write-Host '该版本没有 CUDA 13.x Windows 包。' -ForegroundColor Red; Read-Host '按 Enter 关闭'; exit 1 }

$tmp = Join-Path $env:TEMP ('llama-update-' + $latest)
Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Path $tmp | Out-Null
$zip = Join-Path $tmp 'pkg.zip'

Write-Host ("下载 {0} ({1:N0} MB) ..." -f $asset.name, ($asset.size / 1MB))
Invoke-WebRequest $asset.browser_download_url -OutFile $zip -UseBasicParsing -TimeoutSec 3600

Write-Host '下载完成，正在解压 ...'
Expand-Archive -Path $zip -DestinationPath $tmp -Force
$inner = Get-ChildItem $tmp -Directory | Select-Object -First 1
if (-not $inner) { Write-Host '解压结果异常。' -ForegroundColor Red; Read-Host '按 Enter 关闭'; exit 1 }


if (-not (Test-Path (Join-Path $inner.FullName 'llama-server.exe'))) {
    Write-Host '新包里没有 llama-server.exe，已中止（原目录未改动）。' -ForegroundColor Red
    Read-Host '按 Enter 关闭'; exit 1
}

# 先把新文件完整复制到暂存目录，确认成功后再动 $root
$stage = Join-Path $tmp 'stage'
Remove-Item $stage -Recurse -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Path $stage -Force | Out-Null
Get-ChildItem $inner.FullName -Recurse -File | ForEach-Object {
    $rel2 = $_.FullName.Substring($inner.FullName.Length + 1)
    $dest = Join-Path $stage $rel2
    $destDir = Split-Path -Parent $dest
    if (-not (Test-Path $destDir)) { New-Item -ItemType Directory -Path $destDir -Force | Out-Null }
    Copy-Item $_.FullName $dest -Force
}
$stagedCount = @(Get-ChildItem $stage -Recurse -File).Count
if ($stagedCount -lt 5 -or -not (Test-Path (Join-Path $stage 'llama-server.exe'))) {
    Write-Host '暂存复制失败，已中止（原目录未改动）。' -ForegroundColor Red
    Read-Host '按 Enter 关闭'; exit 1
}

# 升级前停引擎：防止 exe 被占用导致覆盖失败
$procName = [IO.Path]::GetFileNameWithoutExtension($exe)
if ([string]::IsNullOrWhiteSpace($procName)) { $procName = 'llama-server' }
$running = @(Get-Process -Name $procName -ErrorAction SilentlyContinue)
if ($running.Count -gt 0) {
    Write-Host ("检测到 {0} 个引擎进程在运行，正在停止 ..." -f $running.Count) -ForegroundColor Yellow
    $running | Stop-Process -Force -ErrorAction SilentlyContinue
    Start-Sleep -Milliseconds 1500
    $still = @(Get-Process -Name $procName -ErrorAction SilentlyContinue)
    if ($still.Count -gt 0) {
        Write-Host '无法停止引擎进程（可能权限不足），升级中止。请手动关闭引擎后再试。' -ForegroundColor Red
        Read-Host '按 Enter 关闭'; exit 1
    }
    Write-Host '引擎已停止。' -ForegroundColor Green
}

$backup = Join-Path (Split-Path -Parent $engineDir) ('llama.cpp-backup-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
Write-Host ('正在备份原目录到: ' + $backup)
Copy-Item $engineDir $backup -Recurse -Force

Write-Host '正在清理旧程序文件（配置、模板、脚本、日志、模型、说明保持不动）...'
$keep = @('settings.json', 'models.cache.json', 'console.log', 'server.log', 'server.err.log')
$keepExt = @('.jinja', '.ps1', '.vbs', '.bat', '.json', '.lnk', '.gguf', '.txt', '.md', '.zip', '.log')
Get-ChildItem $engineDir -Recurse -File | ForEach-Object {
    $n = $_.Name.ToLowerInvariant()
    if ($keep -contains $n) { return }
    if ($keepExt -contains $_.Extension.ToLowerInvariant()) { return }
    Remove-Item $_.FullName -Force -ErrorAction SilentlyContinue
}

Write-Host '正在移入新程序文件 ...'
Get-ChildItem $stage -Recurse -File | ForEach-Object {
    $rel3 = $_.FullName.Substring($stage.Length + 1)
    $dest = Join-Path $engineDir $rel3
    $destDir = Split-Path -Parent $dest
    if (-not (Test-Path $destDir)) { New-Item -ItemType Directory -Path $destDir -Force | Out-Null }
    Move-Item $_.FullName $dest -Force
}

Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue

# 只保留最近 3 个备份，更早的自动清理
$backupRoot = Split-Path -Parent $engineDir
if (-not [string]::IsNullOrWhiteSpace($backupRoot) -and (Test-Path -LiteralPath $backupRoot)) {
    $oldBackups = @(Get-ChildItem $backupRoot -Directory -Filter 'llama.cpp-backup-*' -ErrorAction SilentlyContinue |
                    Sort-Object Name -Descending | Select-Object -Skip 3)
    foreach ($ob in $oldBackups) {
        Write-Host ('清理旧备份：' + $ob.Name)
        Remove-Item $ob.FullName -Recurse -Force -ErrorAction SilentlyContinue
    }
}

$now = Get-LocalBuild
if ($now -eq $latest) {
    Write-Host ("更新完成: build {0}" -f $now) -ForegroundColor Green
    Write-Host '请回到控制台点「停止服务」再「启动服务」以加载新版本。'
} else {
    Write-Host ("更新后版本仍为 build {0}，请检查是否被占用。" -f $now) -ForegroundColor Yellow
}
Read-Host '按 Enter 关闭'
