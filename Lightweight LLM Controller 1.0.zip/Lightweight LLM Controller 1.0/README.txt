# Lightweight LLM Controller 使用指南

## 1. 项目简介

Lightweight LLM Controller 是一个基于 PowerShell + WinForms 的本地大模型图形控制台，用于替代臃肿的 Electron 客户端（如 LM Studio）。它通过调用 `llama-server.exe` 提供本地推理服务，支持动态调整思考等级（Reasoning Effort）、多模型配置、自定义引擎路径等功能，内存占用低，启动迅速。

## 2. 系统要求

- **操作系统**：Windows 10 / 11（64 位）
- **PowerShell**：5.1 或更高版本（系统自带）
- **显卡**：NVIDIA 显卡（推荐），或使用 CPU 模式
- **磁盘空间**：至少 500 MB 用于存放引擎，模型文件另计（通常 2–40 GB）

## 3. 准备工作

### 3.1 下载推理引擎（llama-server.exe）

本控制台本身不包含推理引擎，需自行下载 llama.cpp 官方编译的 Windows 版本。

1. 访问官方发布页：  
   https://github.com/ggml-org/llama.cpp/releases

2. 根据显卡驱动选择正确的 CUDA 版本：
   - 打开命令提示符（cmd），运行 `nvidia-smi`，查看右上角 `CUDA Version`。
   - 若显示 **12.x**，下载 `llama-*-bin-win-cuda-12.4-x64.zip`（兼容性最好）。
   - 若显示 **13.x**，可下载对应的 `llama-*-bin-win-cuda-13.x-x64.zip`（性能更优）。
   - 若无 NVIDIA 显卡，下载 `llama-*-bin-win-cpu-x64.zip`（速度较慢）。

3. 解压下载的压缩包，将其中的 `llama-server.exe` 及所有 `.dll` 文件放入本程序目录下的 `engine` 文件夹内（若没有该文件夹请新建）。

> **注意**：若启动时提示缺少 `cudart64_*.dll`，需在同一发布页下载对应的 `cudart-llama-bin-win-cuda-*.zip`，解压后将所有 DLL 放入 `engine` 文件夹。

### 3.2 准备模型文件

模型文件（`.gguf` 格式）需单独下载，推荐从 Hugging Face 或 ModelScope 获取。常用模型包括 Qwen、Llama、DeepSeek 等系列。

下载后记住模型文件的存放路径，后续在控制台中选择即可。

## 4. 首次配置

1. **启动控制台**  
   双击 `启动控制台.vbs`（无黑框启动）。

2. **设置引擎路径**  
   点击右下角【设置...】→ 在「引擎路径」栏点击【浏览...】→ 选中 `engine\llama-server.exe` → 点击【关闭】。此步骤只需做一次，配置会自动保存。

3. **选择模型文件**  
   在「服务设置」页，找到「模型文件」一栏，点击【浏览...】选中你的 `.gguf` 文件。

4. **启动服务**  
   点击左下角【启动服务】，等待状态栏显示「运行中 端口 8090 就绪」。

5. **开始对话**  
   切换到「对话」页，输入问题，点击【发送 (Enter)】即可。

## 5. 常见问题

| 问题 | 解决方法 |
|------|----------|
| 启动服务时提示「未找到有效引擎路径」 | 前往【设置...】重新选择 `llama-server.exe` |
| 端口被占用（如 8090 已被其他程序使用） | 在「服务设置」页将「端口」改为其他数值（如 8091） |
| 显存不足导致启动失败 | 将「GPU 层数」调小（如从 999 改为 10~15） |
| 杀毒软件拦截 `llama-server.exe` | 将整个程序目录加入杀毒软件信任区 |
| 思考等级拉条灰色不可用 | 模型名称需包含 `qwen3.5` 等关键词，或前往【设置...】→「配置思考白名单...」中添加 |

## 6. 更新引擎

点击【设置...】→【检查更新...】，程序会自动从 GitHub 下载最新 CUDA 版本并替换 `engine` 目录中的文件。更新前请确保网络通畅，更新过程中会自动停止正在运行的引擎。

## 7. 文件结构说明

```
Lightweight-LLM-Controller/
├── 控制台.ps1                 # 主程序
├── autostart.ps1             # 开机自启脚本
├── 升级.ps1                  # 引擎更新脚本
├── 启动控制台.vbs            # 无黑框启动器
├── settings.json             # 配置文件（首次使用需设置引擎路径）
├── qwen35-effort.jinja       # 思考控制模板
├── auto_generic_effort.jinja # 通用兜底模板
├── engine/                   # 推理引擎目录（需自行放置 llama-server.exe 及 DLL）
└── 首次使用说明.txt           # 本指南
```

---

**提示**：本程序为绿色免安装软件，解压即用。配置保存在 `settings.json` 中，迁移时只需复制整个文件夹。