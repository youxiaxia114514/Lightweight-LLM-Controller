﻿param(
    [switch]$SelfTest,
    [switch]$ChatTest,
    [string]$Prompt = '用一句话介绍你自己',
    [switch]$NoChat,
    [int]$TabIndex = 0,
        [switch]$PresetTest,
    [string]$AutoSend = ''
)
# ============ 全局初始化 ============
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Net.Http
[System.Windows.Forms.Application]::EnableVisualStyles()
$script:root        = Split-Path -Parent $MyInvocation.MyCommand.Path
$script:settingsPath = Join-Path $script:root 'settings.json'
$script:cachePath   = Join-Path $script:root 'models.cache.json'
$script:serverExe   = Join-Path $script:root 'llama-server.exe'
$script:uiLog       = Join-Path $script:root 'console.log'
$script:serverLog   = Join-Path $script:root 'server.log'
$script:serverErr   = Join-Path $script:root 'server.err.log'
$script:startedSignature = ''
$script:loadedModel = ''
$script:DefaultConfig = [ordered]@{
    model = ''; port = 8090; ctx = 65536; ngl = 21; kv = 'q8_0'; threads = 7; parallel = 1
    batch = 1024; ubatch = 512; nPredict = -1; seed = -1; temp = 0.7; topP = 0.95; topK = 20
    minP = 0; repeatPen = 1; flash = 'auto'; kvUnified = $true; template = ''; kvOffload = $true
    mlock = $false; mmap = $true; threadsBatch = 0; prio = 0; noWarmup = $false; contBatch = $true
    reasoningBudget = 0; systemPrompt = ''; apiKey = ''; verbose = $false; metrics = $false
    slots = $false; extra = @(); effort_keywords = @('qwen3.5'); effort = 'medium'; engineExe = ''
}
# 通用兜底模板（ChatML + 思考开关注入）
$script:GenericTemplateContent = @'
{%- if messages %}
    {%- for message in messages %}
        <|im_start|>{{ message.role }}
{{ message.content }}<|im_end|>
    {%- endfor %}
{%- endif %}
{%- if add_generation_prompt %}
<|im_start|>assistant
{%- if enable_thinking is defined and enable_thinking is false %}
<think></think>
{%- else %}
{%- set _eff = reasoning_effort if reasoning_effort is defined and reasoning_effort else 'medium' %}
{%- if _eff == 'low' %}
<think>
Think briefly.
{%- elif _eff == 'high' %}
<think>
Think deeply.
{%- elif _eff == 'xhigh' %}
<think>
Think very deeply and verify each step.
{%- elif _eff == 'max' %}
<think>
Think as thoroughly as possible.
{%- else %}
<think>
{%- endif %}
{%- endif %}
{%- endif %}
'@
# 每个模型独立配置：键为模型绝对路径
$script:PerModelKeys = @('ctx', 'ngl', 'kv', 'threads', 'parallel', 'batch', 'ubatch', 'nPredict', 'seed', 'temp', 'topP', 'topK', 'minP', 'repeatPen', 'flash', 'kvUnified', 'template', 'kvOffload', 'mlock', 'mmap', 'threadsBatch', 'prio', 'noWarmup', 'contBatch', 'reasoningBudget', 'systemPrompt', 'extra', 'effort')
$script:modelConfigs = @{}
$script:effortKeywords = @('qwen3.5')
$script:autoTemplate = ''
$script:layoutOrder = @()
$__tplDefault = Join-Path $script:root 'qwen35-effort.jinja'
if (Test-Path $__tplDefault) { $script:DefaultConfig['template'] = $__tplDefault }
$script:switchingModel = $false
$script:currentModel = ''
function Write-UiLog([string]$m) {
    try { Add-Content -LiteralPath $script:uiLog -Value ('[{0}] {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $m) -Encoding UTF8 } catch { }
}
function Show-Fatal([string]$where, $err) {
    $msg = '位置：' + $where + [Environment]::NewLine + $err.Exception.Message
    Write-UiLog ('错误 ' + $where + ' : ' + $err.Exception.ToString())
    try { [void][System.Windows.Forms.MessageBox]::Show($msg, 'llama.cpp 控制台 - 出错', 'OK', 'Error') } catch { }
}
function Select-File {
    param([string]$FileFilter, [string]$Title = '选择文件')
    $dlg = New-Object System.Windows.Forms.OpenFileDialog
    $dlg.Filter = $FileFilter
    $dlg.Title = $Title
    if ($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { return $dlg.FileName }
    return $null
}
function Split-ArgsLine([string]$line) {
    if ([string]::IsNullOrWhiteSpace($line)) { return @() }
    $rx = '"[^"]*"|''[^'']*''|\S+'
    $out = @()
    foreach ($m in [regex]::Matches($line, $rx)) {
        $v = $m.Value
        if ($v.Length -ge 2) {
            $h = $v.Substring(0, 1); $t = $v.Substring($v.Length - 1, 1)
            if (($h -eq '"' -and $t -eq '"') -or ($h -eq "'" -and $t -eq "'")) { $v = $v.Substring(1, $v.Length - 2) }
        }
        if ($v -ne '') { $out += $v }
    }
    return $out
}
function ConvertTo-ExtraRows($value) {
    $list = New-Object System.Collections.ArrayList
    if ($null -eq $value) { return @() }
    if ($value -is [string]) {
        $tokens = @(Split-ArgsLine ([string]$value))
        $i = 0
        while ($i -lt $tokens.Count) {
            $k = [string]$tokens[$i]
            $v = ''
            if (($i + 1) -lt $tokens.Count -and -not ([string]$tokens[$i + 1]).StartsWith('--')) {
                $v = [string]$tokens[$i + 1]
                $i += 2
            } else { $i += 1 }
            if (-not [string]::IsNullOrWhiteSpace($k)) { [void]$list.Add(@{ key = $k; value = $v }) }
        }
        return $list.ToArray()
    }
    foreach ($item in @($value)) {
        $k = ''
        $v = ''
        if ($item -is [string]) {
            $k = [string]$item
        } else {
            $pk = $item.PSObject.Properties['key']
            if ($null -eq $pk) { $pk = $item.PSObject.Properties['name'] }
            $pv = $item.PSObject.Properties['value']
            if ($null -ne $pk) { $k = [string]$pk.Value }
            if ($null -ne $pv) { $v = [string]$pv.Value }
        }
        if (-not [string]::IsNullOrWhiteSpace($k)) { [void]$list.Add(@{ key = $k; value = $v }) }
    }
    return $list.ToArray()
}
function Get-ExtraRows {
    $rows = New-Object System.Collections.ArrayList
    if ($null -eq $script:ui -or $null -eq $script:ui.extra) { return $rows.ToArray() }
    foreach ($r in $script:ui.extra.Rows) {
        if ($null -eq $r) { continue }
        $k = ''
        $v = ''
        if ($null -ne $r.Cells[0].Value) { $k = [string]$r.Cells[0].Value }
        if ($null -ne $r.Cells[1].Value) { $v = [string]$r.Cells[1].Value }
        if ([string]::IsNullOrWhiteSpace($k)) { continue }
        [void]$rows.Add([ordered]@{ key = $k.Trim(); value = $v.Trim() })
    }
    return $rows.ToArray()
}
function Load-Config {
    $c = [ordered]@{}
    foreach ($k in $script:DefaultConfig.Keys) { $c[$k] = $script:DefaultConfig[$k] }
    if (Test-Path -LiteralPath $script:settingsPath) {
        try {
            $saved = Get-Content -LiteralPath $script:settingsPath -Raw -Encoding UTF8 | ConvertFrom-Json
            foreach ($k in $script:DefaultConfig.Keys) {
                $prop = $saved.PSObject.Properties[$k]
                if ($null -ne $prop -and $null -ne $prop.Value) { $c[$k] = $prop.Value }
            }
            $loProp = $saved.PSObject.Properties['layout_order']
            if ($null -ne $loProp -and $null -ne $loProp.Value) { $script:layoutOrder = @($loProp.Value) }
            $mcProp = $saved.PSObject.Properties['model_configs']
            if ($null -ne $mcProp -and $null -ne $mcProp.Value) { $script:modelConfigs = ConvertTo-Hash $mcProp.Value }
            $ekProp = $saved.PSObject.Properties['effort_keywords']
            if ($null -ne $ekProp -and $null -ne $ekProp.Value) { $script:effortKeywords = @($ekProp.Value | ForEach-Object { ([string]$_).Trim() } | Where-Object { $_ -ne '' }) }
        } catch { Write-UiLog ('settings.json 读取失败: ' + $_.Exception.Message) }
    }
    $c['extra'] = @(ConvertTo-ExtraRows $c['extra'])
    if ([string]::IsNullOrWhiteSpace([string]$c['engineExe'])) {
        $localExe0 = Join-Path $script:root 'llama-server.exe'
        if (Test-Path -LiteralPath $localExe0) { $c['engineExe'] = $localExe0 }
    }
    $mcKey = [string]$c['model']
    if ($mcKey -ne '' -and $script:modelConfigs.ContainsKey($mcKey)) {
        $c = Apply-PerModelBlock $c $script:modelConfigs[$mcKey]
        $c['extra'] = @(ConvertTo-ExtraRows $c['extra'])
    }
    return $c
}
function Save-Config([hashtable]$c, [switch]$SkipPerModel) {
    $mcKey = [string]$c['model']
    if ($mcKey -ne '' -and -not $SkipPerModel) { $script:modelConfigs[$mcKey] = Get-PerModelBlock $c }
    $out = [ordered]@{}
    foreach ($k in $script:DefaultConfig.Keys) { $out[$k] = $c[$k] }
    $out['model_configs'] = $script:modelConfigs
    $out['layout_order'] = @($script:order)
    $out['effort_keywords'] = @($script:effortKeywords)
    $json = $out | ConvertTo-Json -Depth 8
    [IO.File]::WriteAllText($script:settingsPath, $json, (New-Object System.Text.UTF8Encoding($true)))
}
function ConvertTo-Hash($v) {
    $h = @{}
    if ($null -eq $v) { return $h }
    if ($v -is [System.Collections.IDictionary]) {
        foreach ($k in @($v.Keys)) { $h[[string]$k] = ConvertTo-Hash $v[$k] }
        return $h
    }
    if ($v -is [pscustomobject]) {
        foreach ($prop in $v.PSObject.Properties) { $h[[string]$prop.Name] = ConvertTo-Hash $prop.Value }
        return $h
    }
    return $v
}
function Get-BlockValue($block, [string]$key) {
    if ($null -eq $block) { return $null }
    if ($block -is [System.Collections.IDictionary]) {
        if ($block.Contains($key)) { return $block[$key] }
        return $null
    }
    $prop = $block.PSObject.Properties[$key]
    if ($null -eq $prop) { return $null }
    return $prop.Value
}
function Get-PerModelBlock([hashtable]$c) {
    $b = [ordered]@{}
    foreach ($k in $script:PerModelKeys) { $b[$k] = $c[$k] }
    return $b
}
function Apply-PerModelBlock([hashtable]$c, $block) {
    foreach ($k in $script:PerModelKeys) {
        $v = Get-BlockValue $block $k
        if ($null -ne $v) { $c[$k] = $v }
    }
    return $c
}
# ============ 模型发现（带缓存 + 深度限制） ============
function Get-ModelDirs([string]$current) {
    $dirs = New-Object System.Collections.Generic.List[string]
    if (-not [string]::IsNullOrWhiteSpace($current)) {
        $d = Split-Path -Parent $current
        if (Test-Path -LiteralPath $d) { $dirs.Add($d) }
    }
    foreach ($p in @("$env:USERPROFILE\.lmstudio\models", 'C:\软件\models', 'D:\models', "$env:USERPROFILE\models")) {
        if ((Test-Path -LiteralPath $p) -and -not $dirs.Contains($p)) { $dirs.Add($p) }
    }
    return $dirs
}
function Find-Gguf([string]$dir, [int]$maxDepth) {
    $found = @()
    $queue = New-Object System.Collections.Queue
    $queue.Enqueue(@($dir, 0))
    while ($queue.Count -gt 0) {
        $item = $queue.Dequeue()
        $path = [string]$item[0]; $depth = [int]$item[1]
        try { $files = [IO.Directory]::GetFiles($path, '*.gguf') } catch { $files = @() }
        foreach ($f in $files) {
            if ([IO.Path]::GetFileName($f) -notmatch '^mmproj') { $found += $f }
        }
        if ($depth -lt $maxDepth) {
            try { $subs = [IO.Directory]::GetDirectories($path) } catch { $subs = @() }
            foreach ($s in $subs) { $queue.Enqueue(@($s, $depth + 1)) }
        }
    }
    return $found
}
function Get-Models([string]$current, [switch]$NoCache) {
    $items = New-Object System.Collections.ArrayList
    if (-not $NoCache -and (Test-Path -LiteralPath $script:cachePath)) {
        try {
            $cache = Get-Content -LiteralPath $script:cachePath -Raw -Encoding UTF8 | ConvertFrom-Json
            $age = (Get-Date) - [datetime]$cache.time
            if ($age.TotalHours -lt 12 -and $cache.files) {
                foreach ($f in $cache.files) {
                    if (Test-Path -LiteralPath $f) {
                        $gb = [math]::Round((Get-Item -LiteralPath $f).Length / 1GB, 1)
                        [void]$items.Add([pscustomobject]@{ Text = ('{0}  [{1} GB]' -f [IO.Path]::GetFileNameWithoutExtension($f), $gb); Name = [IO.Path]::GetFileNameWithoutExtension($f); Size = $gb; Path = $f })
                    }
                }
                if ($items.Count -gt 0) { return @($items) }
            }
        } catch { Write-UiLog ('模型缓存读取失败: ' + $_.Exception.Message) }
    }
    $files = @()
    foreach ($d in (Get-ModelDirs $current)) { $files += Find-Gguf $d 4 }
    $files = @($files | Sort-Object -Unique)
    if (-not [string]::IsNullOrWhiteSpace($current) -and -not ($files -contains $current)) { $files = @($current) + $files }
    foreach ($f in $files) {
        $gb = 0
        try { $gb = [math]::Round((Get-Item -LiteralPath $f).Length / 1GB, 1) } catch { }
        [void]$items.Add([pscustomobject]@{ Text = ('{0}  [{1} GB]' -f [IO.Path]::GetFileNameWithoutExtension($f), $gb); Name = [IO.Path]::GetFileNameWithoutExtension($f); Size = $gb; Path = $f })
    }
    try {
        $payload = @{ time = (Get-Date).ToString('o'); files = $files } | ConvertTo-Json
        [IO.File]::WriteAllText($script:cachePath, $payload, (New-Object System.Text.UTF8Encoding($true)))
    } catch { Write-UiLog ('模型缓存写入失败: ' + $_.Exception.Message) }
    if ($items.Count -eq 0) { return @() }
    return @($items)
}
# ============ 启动参数 ============
function Find-Mmproj([string]$model) {
    if ([string]::IsNullOrWhiteSpace($model)) { return '' }
    $dir = Split-Path -Parent $model
    if (-not (Test-Path -LiteralPath $dir)) { return '' }
    $f = Get-ChildItem -LiteralPath $dir -Filter 'mmproj*.gguf' -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($null -eq $f) { return '' }
    return $f.FullName
}
function Build-Arguments([hashtable]$c) {
    $a = @('--model', (Q ([string]$c.model)), '--host', '127.0.0.1', '--port', [string]$c.port,
        '--ctx-size', [string]$c.ctx, '--n-gpu-layers', [string]$c.ngl,
        '--cache-type-k', [string]$c.kv, '--cache-type-v', [string]$c.kv,
        '--threads', [string]$c.threads, '--parallel', [string]$c.parallel,
        '--batch-size', [string]$c.batch, '--ubatch-size', [string]$c.ubatch,
        '--n-predict', [string]$c.nPredict, '--seed', [string]$c.seed,
        '--temp', [string]$c.temp, '--top-p', [string]$c.topP, '--top-k', [string]$c.topK,
        '--min-p', [string]$c.minP, '--repeat-penalty', [string]$c.repeatPen,
        '--jinja', '--alias', (Q ([IO.Path]::GetFileNameWithoutExtension([string]$c.model))))
    $flash = [string]$c.flash
    if ($flash -eq 'on') { $a += @('--flash-attn', 'on') }
    elseif ($flash -eq 'off') { $a += @('--flash-attn', 'off') }
    # auto 时什么都不加，让 llama.cpp 自己判断
    if ($c.kvUnified) { $a += '--kv-unified' } else { $a += '--no-kv-unified' }
    $tplPath = [string]$c.template
    if (-not [string]::IsNullOrWhiteSpace($tplPath) -and -not (Test-Path -LiteralPath $tplPath)) {
        $alt = Join-Path $script:root ([IO.Path]::GetFileName($tplPath))
        if (Test-Path -LiteralPath $alt) {
            $tplPath = $alt
        } else {
            Write-UiLog ('警告: 未找到思考模板文件，思考等级拉条将失效！ (' + [string]$c.template + ')')
            $tplPath = ''
        }
    }
    if (-not [string]::IsNullOrWhiteSpace($tplPath) -and (Test-Path -LiteralPath $tplPath)) {
        $a += @('--chat-template-file', (Q $tplPath))
    }
    $mp = Find-Mmproj ([string]$c.model)
    if ($mp -ne '') { $a += @('--mmproj', (Q $mp)) }
    if (-not $c.kvOffload) { $a += '--no-kv-offload' }
    if ($c.mlock) { $a += '--mlock' }
    if (-not $c.mmap) { $a += '--no-mmap' }
    if ([int]$c.threadsBatch -gt 0) { $a += @('--threads-batch', [string]$c.threadsBatch) }
    if ([int]$c.prio -gt 0) { $a += @('--prio', [string]$c.prio) }
    if ($c.noWarmup) { $a += '--no-warmup' }
    if (-not $c.contBatch) { $a += '--no-cont-batching' }
    if (Test-EffortAllowed ([string]$c.model)) {
        # 物理上限兜底：档位由前端 chat_template_kwargs 动态控制，这里固定一个防失控上限
        $a += @('--reasoning-budget', '4096')
    }
    if (-not [string]::IsNullOrWhiteSpace([string]$c.apiKey)) { $a += @('--api-key', (Q ([string]$c.apiKey))) }
    if ($c.verbose) { $a += '--verbose' }
    if ($c.metrics) { $a += '--metrics' }
    if ($c.slots) { $a += '--slots' }
    if ($null -ne $c.extra) {
        foreach ($row in @($c.extra)) {
            $k = [string]$row.key
            if ([string]::IsNullOrWhiteSpace($k)) { continue }
            $k = $k.Trim()
            if (-not $k.StartsWith('--')) { $k = '--' + $k }
            $v = [string]$row.value
            if ([string]::IsNullOrWhiteSpace($v)) { $a += $k } else { $a += @($k, (Q $v.Trim())) }
        }
    }
    return $a
}
function Get-EngineProcessName {
    if ($null -eq $script:cfg) { return 'llama-server' }
    $exe = [string]$script:cfg['engineExe']
    if ([string]::IsNullOrWhiteSpace($exe)) { $exe = Join-Path $script:root 'llama-server.exe' }
    $n = [IO.Path]::GetFileNameWithoutExtension($exe)
    if ([string]::IsNullOrWhiteSpace($n)) { return 'llama-server' }
    return $n
}
function Test-EngineRunning {
    $pn = Get-EngineProcessName
    return (@(Get-Process -Name $pn -ErrorAction SilentlyContinue).Count -gt 0)
}
function Start-Engine([hashtable]$c) {
    $exe = [string]$c['engineExe']
    if ([string]::IsNullOrWhiteSpace($exe)) {
        $localExe = Join-Path $script:root 'llama-server.exe'
        if (Test-Path -LiteralPath $localExe) { $exe = $localExe }
    }
    if ([string]::IsNullOrWhiteSpace($exe) -or -not (Test-Path -LiteralPath $exe)) {
        [void][System.Windows.Forms.MessageBox]::Show('未找到有效的引擎路径，请在【设置】中配置 llama-server.exe！', '提示')
        return $false
    }
    $workDir = [IO.Path]::GetDirectoryName($exe)
    if ([string]::IsNullOrWhiteSpace($workDir)) { $workDir = $script:root }
    Save-Config $c
    $args = Build-Arguments $c
    Write-UiLog ('启动: ' + $exe + ' ' + ($args -join ' '))
    Start-Process -FilePath $exe -ArgumentList $args -WorkingDirectory $workDir -WindowStyle Minimized -RedirectStandardOutput $script:serverLog -RedirectStandardError $script:serverErr | Out-Null
    $script:startedSignature = Get-ConfigSignature $c
    $script:loadedModel = [string]$c.model
    return $true
}
function Stop-Engine {
    $pn = Get-EngineProcessName
    Get-Process -Name $pn -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
}
function Get-ConfigSignature($c) {
    $parts = @()
    foreach ($k in ($c.Keys | Sort-Object)) {
        if ($k -eq 'effort') { continue }
        if ($k -eq 'extra') {
            $rows = @()
            foreach ($r in @($c['extra'])) { $rows += ('{0}={1}' -f [string]$r.key, [string]$r.value) }
            $parts += ('extra[' + ($rows -join '|') + ']')
        } else {
            $parts += ('{0}={1}' -f $k, [string]$c[$k])
        }
    }
    return ($parts -join ';')
}
function Get-AutoTemplatePath {
    $j = Join-Path $script:root 'qwen35-effort.jinja'
    if (Test-Path -LiteralPath $j) { return $j }
    return ''
}
    function Get-GenericTemplatePath {
        $gp = Join-Path $script:root 'auto_generic_effort.jinja'
        try {
            $need = $true
            if (Test-Path -LiteralPath $gp) {
                $old = [IO.File]::ReadAllText($gp, [Text.Encoding]::UTF8)
                if ($old -eq $script:GenericTemplateContent) { $need = $false }
            }
            if ($need) { [IO.File]::WriteAllText($gp, $script:GenericTemplateContent, (New-Object System.Text.UTF8Encoding($false))) }
        } catch { }
        return $gp
    }

function Q([string]$s) {
    $v = [string]$s
    if ($v -eq '') { return '' }
    if ($v.Contains('"')) { $v = $v -replace '"', '\"' }
    if ($v -match '\s') { return '"' + $v + '"' }
    return $v
}
function Sync-ChatModels {
    if ($null -eq $script:ui -or $null -eq $script:cmbChat) { return }
    if ($null -eq $script:ui.model) { return }
    try {
        $script:syncingChat = $true
        $cur = ''
        if ($null -ne $script:ui.model.SelectedItem) { $cur = [string]$script:ui.model.SelectedItem.Path }
        $script:cmbChat.Items.Clear()
        foreach ($m0 in $script:ui.model.Items) { [void]$script:cmbChat.Items.Add($m0) }
        $pick = $null
        foreach ($m1 in $script:cmbChat.Items) { if ([string]$m1.Path -eq $cur) { $pick = $m1; break } }
        if ($null -ne $pick) { $script:cmbChat.SelectedItem = $pick } elseif ($script:cmbChat.Items.Count -gt 0) { $script:cmbChat.SelectedIndex = 0 }
    } catch { } finally { $script:syncingChat = $false }
}
function Get-SeriesKeyword([string]$name) {
    $n = ([string]$name).Trim()
    if ($n -eq '') { return '' }
    $ln = $n.ToLowerInvariant()
    if ($ln.Contains('deepseek') -or $ln.Contains('r1')) { return '' }
    if ($n -match '(?i)\b(qwen\d+(?:\.\d+)?)') { return $Matches[1].ToLowerInvariant() }
    if ($n -match '(?i)\b(llama[\d.]*)') { return $Matches[1].ToLowerInvariant() }
    if ($n -match '(?i)\b(gemma[\d.]*)') { return $Matches[1].ToLowerInvariant() }
    if ($n -match '(?i)\b(deepseek[\w.-]*)') { return ($Matches[1] -split '[.-]')[0].ToLowerInvariant() }
    $seg = ($n -split '[-_ ]')[0]
    if ($seg.Length -ge 3) { return $seg.ToLowerInvariant() }
    return $n.ToLowerInvariant()
}
function Test-EffortAllowed([string]$modelPath) {
    $p = [string]$modelPath
    if ([string]::IsNullOrWhiteSpace($p)) { return $false }
    $name = [IO.Path]::GetFileNameWithoutExtension($p).ToLowerInvariant()
    if ($name.Contains('deepseek') -or $name.Contains('r1')) { return $false }
    foreach ($kw in @($script:effortKeywords)) {
        $k = ([string]$kw).Trim().ToLowerInvariant()
        if ($k -eq '') { continue }
        if ($name.Contains($k)) { return $true }
    }
    return $false
}

function Apply-EffortPolicy([string]$modelPath) {
    if ($null -eq $script:ui -or $null -eq $script:ui.effort -or $null -eq $script:ui.template) { return }
    $allowed = Test-EffortAllowed $modelPath
    $tpl = [string]$script:ui.template.Text
    if ($allowed) {
        $script:ui.effort.Enabled = $true
        if ([string]::IsNullOrWhiteSpace($tpl)) {
            $nmLow = [IO.Path]::GetFileNameWithoutExtension([string]$modelPath).ToLowerInvariant()
            $fill = ''
            if ($nmLow.Contains('qwen') -and -not $nmLow.Contains('deepseek') -and -not $nmLow.Contains('r1')) { $fill = Get-AutoTemplatePath }
            if ([string]::IsNullOrWhiteSpace($fill)) { $fill = Get-GenericTemplatePath }
            if (-not [string]::IsNullOrWhiteSpace($fill)) {
                $script:ui.template.Text = $fill
                $script:autoTemplate = $fill
            }
        }
    } else {
        $script:ui.effort.Enabled = $false
        $script:ui.effort.SelectedItem = 'off'
        if ($script:autoTemplate -ne '' -and $tpl -eq $script:autoTemplate) {
            $script:ui.template.Text = ''
            $script:autoTemplate = ''
        }
    }
    if ($null -ne $script:cfg) { $script:cfg['template'] = [string]$script:ui.template.Text }
}
function New-DefaultConfigForModel([string]$modelPath, $port) {
    $c = [ordered]@{}
    foreach ($k in $script:DefaultConfig.Keys) { $c[$k] = $script:DefaultConfig[$k] }
    # 保留全局 engineExe，不随模型重置
    if ($null -ne $script:cfg -and -not [string]::IsNullOrWhiteSpace([string]$script:cfg['engineExe'])) {
        $c['engineExe'] = [string]$script:cfg['engineExe']
    }
    if ($null -ne $port) { $c['port'] = $port }
    $c['model'] = $modelPath
    $c['template'] = ''
    if (Test-EffortAllowed $modelPath) {
        $auto = Get-AutoTemplatePath
        if ($auto -ne '') { $c['template'] = $auto }
    }
    try {
        $fi = Get-Item -LiteralPath $modelPath -ErrorAction Stop
        $gb = $fi.Length / 1GB
        if ($gb -lt 12) { $c['ngl'] = 999; if ([double]$c['ctx'] -gt 32768) { $c['ctx'] = 32768 } }
    } catch { }
    return $c
}
function Reset-Control([string]$key) {
    if ($null -eq $script:ui) { return }
    $ctrl = $script:ui[$key]
    if ($null -eq $ctrl) { return }
    if (-not $script:DefaultConfig.Contains($key)) { return }
    $v = $script:DefaultConfig[$key]
    if ($ctrl -is [System.Windows.Forms.NumericUpDown]) {
        $x = [double]$v
        if ($x -lt [double]$ctrl.Minimum) { $x = [double]$ctrl.Minimum }
        if ($x -gt [double]$ctrl.Maximum) { $x = [double]$ctrl.Maximum }
        $ctrl.Value = [decimal]$x
    } elseif ($ctrl -is [System.Windows.Forms.ComboBox]) {
        $s = [string]$v
        foreach ($it in $ctrl.Items) { if ([string]$it -eq $s) { $ctrl.SelectedItem = $it; break } }
    } elseif ($ctrl -is [System.Windows.Forms.CheckBox]) {
        $ctrl.Checked = [bool]$v
    } elseif ($ctrl -is [System.Windows.Forms.TextBox]) {
        $ctrl.Text = [string]$v
    } elseif ($ctrl -is [System.Windows.Forms.DataGridView]) {
        $ctrl.Rows.Clear()
    }
}

function Reset-ToDefaults {
    if ($null -eq $script:ui.model.SelectedItem) { return }
    $modelPath = [string]$script:ui.model.SelectedItem.Path
    $ans = [System.Windows.Forms.MessageBox]::Show('确定要将当前选中模型的所有参数恢复为默认值吗？', '重置配置', 'YesNo', 'Question')
    if ($ans -ne [System.Windows.Forms.DialogResult]::Yes) { return }
    $script:switchingModel = $true
    try {
        foreach ($k in $script:PerModelKeys) { if ($k -eq 'extra') { $script:ui.extra.Rows.Clear() } else { Reset-Control $k } }
        Reset-Control 'port'
        $script:cfg = Read-Config
        $script:modelConfigs.Remove($modelPath)
        Save-Config $script:cfg -SkipPerModel
    } finally { $script:switchingModel = $false }
    $lblChat.Text = '参数已恢复默认'
    $lblStatus.Text = '✔ 参数已恢复默认'
    $lblStatus.ForeColor = [System.Drawing.Color]::FromArgb(0, 150, 0)
    if ($script:saveFlash) { $script:saveFlash.Stop(); $script:saveFlash.Start() }
}

function Set-UiFromConfig([hashtable]$c) {
    $script:switchingModel = $true
    $script:currentModel = [string]$c['model']
    try {
        if ($null -ne $script:ui.model -and [string]$c['model'] -ne '') {
            foreach ($it in $script:ui.model.Items) { if ([string]$it.Path -eq [string]$c['model']) { $script:ui.model.SelectedItem = $it; break } }
        }
        $nums = @{ ctx = $c['ctx']; ngl = $c['ngl']; threads = $c['threads']; parallel = $c['parallel']; batch = $c['batch']; ubatch = $c['ubatch']; nPredict = $c['nPredict']; seed = $c['seed']; threadsBatch = $c['threadsBatch']; reasoningBudget = $c['reasoningBudget'] }
        foreach ($k in $nums.Keys) {
            $ctrl = $script:ui[$k]
            if ($null -eq $ctrl -or $null -eq $nums[$k]) { continue }
            $val = [double]$nums[$k]
            if ($val -lt [double]$ctrl.Minimum) { $val = [double]$ctrl.Minimum }
            if ($val -gt [double]$ctrl.Maximum) { $val = [double]$ctrl.Maximum }
            $ctrl.Value = [decimal]$val
        }
        $decs = @{ temp = $c['temp']; topP = $c['topP']; topK = $c['topK']; minP = $c['minP']; repeatPen = $c['repeatPen'] }
        foreach ($k in $decs.Keys) {
            $ctrl = $script:ui[$k]
            if ($null -eq $ctrl -or $null -eq $decs[$k]) { continue }
            $val = [double]$decs[$k]
            if ($val -lt [double]$ctrl.Minimum) { $val = [double]$ctrl.Minimum }
            if ($val -gt [double]$ctrl.Maximum) { $val = [double]$ctrl.Maximum }
            $ctrl.Value = [decimal]$val
        }
        if ($script:ui.kv.Items -contains [string]$c['kv']) { $script:ui.kv.SelectedItem = [string]$c['kv'] }
        if ($script:ui.flash.Items -contains [string]$c['flash']) { $script:ui.flash.SelectedItem = [string]$c['flash'] }
        $script:ui.kvUnified.Checked = [bool]$c['kvUnified']
        $script:ui.kvOffload.Checked = [bool]$c['kvOffload']
        $script:ui.mmap.Checked = [bool]$c['mmap']
        $script:ui.contBatch.Checked = [bool]$c['contBatch']
        $script:ui.template.Text = [string]$c['template']
        if (-not [string]::IsNullOrWhiteSpace([string]$c['effort'])) { $e0 = [string]$c['effort']; if ($script:ui.effort.Items -contains $e0) { $script:ui.effort.SelectedItem = $e0 } }
        Update-EffortState ([string]$c['template'])
        $script:ui.systemPrompt.Text = [string]$c['systemPrompt']
        $script:ui.apiKey.Text = [string]$c['apiKey']
        if ($null -ne $script:ui.extra) {
            $script:ui.extra.Rows.Clear()
            foreach ($er in @(ConvertTo-ExtraRows $c['extra'])) { [void]$script:ui.extra.Rows.Add([string]$er.key, [string]$er.value) }
        }
    } finally { $script:switchingModel = $false }
}
function Update-EffortState([string]$tplPath) {
    Apply-EffortPolicy ([string]$script:cfg['model'])
}

# ============ 对话请求 ============
function Get-TokenEstimate([string]$text) {
    if ([string]::IsNullOrEmpty($text)) { return 0 }
    # 中文约 1.5 字/token，英文约 4 字符/token，取折中 1.8
    return [int][Math]::Ceiling($text.Length / 1.8)
}
function Measure-Messages($msgs) {
    $t = 0
    foreach ($m in $msgs) {
        if ($m.content -is [string]) { $t += (Get-TokenEstimate $m.content) }
        else {
            foreach ($part in $m.content) {
                if ($part.type -eq 'text') { $t += (Get-TokenEstimate $part.text) }
                else { $t += 512 }
            }
        }
        $t += 8
    }
    return $t
}
function Trim-Messages($msgs, [int]$budget) {
    $list = @($msgs)
    if ($list.Count -eq 0) { return @() }
    $maxTokens = [int]$script:maxTokens
    $room = [Math]::Max(512, $budget - $maxTokens - 256)
    # 单条超长：分别截断
    for ($i = 0; $i -lt $list.Count; $i++) {
        if ($list[$i].content -is [string]) {
            $est = Get-TokenEstimate $list[$i].content
            $allow = [int]($room * 0.7)
            if ($est -gt $allow -and $allow -gt 200) {
                $maxChars = [int]($allow * 1.8)
                $list[$i] = [pscustomobject]@{ role = $list[$i].role; content = ($list[$i].content.Substring(0, [Math]::Min($maxChars, $list[$i].content.Length)) + "`n…（内容过长，已自动截断）") }
            }
        }
    }
    # 滑动窗口：从最老的开始丢，保留最近两条
    while ((Measure-Messages $list) -gt $room -and $list.Count -gt 2) {
        $list = @($list[1..($list.Count - 1)])
    }
    return $list
}
function Invoke-ChatBlocking([int]$port, [string]$model, $messages, [string]$effort, [int]$maxTokens) {
    $body = @{
        model = $model; messages = @($messages); max_tokens = $maxTokens; temperature = 0.7
        chat_template_kwargs = @{ enable_thinking = ($effort -ne 'off'); reasoning_effort = $effort }
    } | ConvertTo-Json -Depth 12 -Compress
    $uri = 'http://127.0.0.1:' + $port + '/v1/chat/completions'
    $bytes = [Text.Encoding]::UTF8.GetBytes($body)
    $r = Invoke-WebRequest -Uri $uri -Method Post -Body $bytes -ContentType 'application/json; charset=utf-8' -UseBasicParsing -TimeoutSec 600
    return ($r.Content | ConvertFrom-Json)
}
# ============ Markdown 渲染 ============
function Set-Redraw($ctrl, [bool]$on) {
    if (-not $ctrl.IsHandleCreated) { return }
    $wmSetRedraw = 0x000B
    if ($on) {
        [void][Win32.Api]::SendMessage($ctrl.Handle, $wmSetRedraw, [IntPtr]1, [IntPtr]::Zero)
        # WM_SETREDRAW 恢复后必须显式失效并立即重绘，否则 RichTextBox 会保留旧的绘制结果，
        # 表现为“文字已经加进去了，但界面要等鼠标点一下才刷出来”。
        $ctrl.Invalidate()
        $ctrl.Update()
        # RDW_INVALIDATE(0x1) | RDW_ERASE(0x4) | RDW_ALLCHILDREN(0x80) | RDW_UPDATENOW(0x100)
        [void][Win32.Api]::RedrawWindow($ctrl.Handle, [IntPtr]::Zero, [IntPtr]::Zero, 0x0185)
    } else {
        [void][Win32.Api]::SendMessage($ctrl.Handle, $wmSetRedraw, [IntPtr]0, [IntPtr]::Zero)
    }
}
function Repaint-Text($rtb) {
    if ($null -eq $rtb -or -not $rtb.IsHandleCreated) { return }
    $rtb.SelectionStart = $rtb.TextLength
    $rtb.SelectionLength = 0
    $rtb.ScrollToCaret()
    $rtb.Invalidate()
    $rtb.Update()
    [void][Win32.Api]::RedrawWindow($rtb.Handle, [IntPtr]::Zero, [IntPtr]::Zero, 0x0185)
}
function Add-InlineRuns($rtb, [string]$text, $font, $color) {
    $rx = '\*\*(.+?)\*\*|`([^`]+)`'
    $pos = 0
    foreach ($m in [regex]::Matches($text, $rx)) {
        if ($m.Index -gt $pos) {
            $rtb.SelectionStart = $rtb.TextLength; $rtb.SelectionLength = 0
            $rtb.SelectionFont = $font; $rtb.SelectionColor = $color
            $rtb.AppendText($text.Substring($pos, $m.Index - $pos))
        }
        $rtb.SelectionStart = $rtb.TextLength; $rtb.SelectionLength = 0
        if ($m.Groups[1].Success) {
            $rtb.SelectionFont = (New-Object System.Drawing.Font($font, [System.Drawing.FontStyle]::Bold))
            $rtb.SelectionColor = $color
            $rtb.AppendText($m.Groups[1].Value)
        } else {
            $mono = $script:monoFont
            $rtb.SelectionFont = $mono
            $rtb.SelectionColor = [System.Drawing.Color]::FromArgb(180, 40, 90)
            $rtb.AppendText($m.Groups[2].Value)
        }
        $pos = $m.Index + $m.Length
    }
    if ($pos -lt $text.Length) {
        $rtb.SelectionStart = $rtb.TextLength; $rtb.SelectionLength = 0
        $rtb.SelectionFont = $font; $rtb.SelectionColor = $color
        $rtb.AppendText($text.Substring($pos))
    }
}
function Add-Markdown($rtb, [string]$text, $font, $color) {
    Set-Redraw $rtb $false
    try {
    $inCode = $false
    $lines = $text -split "`r?`n"
    foreach ($line in $lines) {
        if ($line.TrimStart().StartsWith('```')) {
            $inCode = -not $inCode
            $rtb.SelectionStart = $rtb.TextLength; $rtb.SelectionLength = 0
            $rtb.SelectionFont = $script:monoFont
            $rtb.SelectionColor = [System.Drawing.Color]::FromArgb(110, 110, 110)
            $rtb.AppendText($line + "`r`n")
            continue
        }
        $rtb.SelectionStart = $rtb.TextLength; $rtb.SelectionLength = 0
        if ($inCode) {
            $rtb.SelectionFont = $script:monoFont
            $rtb.SelectionColor = [System.Drawing.Color]::FromArgb(30, 30, 30)
            $rtb.SelectionBackColor = [System.Drawing.Color]::FromArgb(245, 245, 245)
            $rtb.AppendText($line + "`r`n")
            $rtb.SelectionBackColor = [System.Drawing.Color]::White
        } elseif ($line -match '^(#{1,4})\s+(.*)$') {
            $level = $Matches[1].Length
            $size = 9 + (4 - $level)
            $hf = New-Object System.Drawing.Font($font.FontFamily, $size, [System.Drawing.FontStyle]::Bold)
            $rtb.SelectionFont = $hf; $rtb.SelectionColor = $color
            $rtb.AppendText($Matches[2] + "`r`n")
        } else {
            Add-InlineRuns $rtb $line $font $color
            $rtb.AppendText("`r`n")
        }
    }
    $rtb.SelectionStart = $rtb.TextLength; $rtb.SelectionLength = 0
    $rtb.SelectionFont = $font
    } finally {
        Set-Redraw $rtb $true
    }
    Repaint-Text $rtb
}
# ============ 主程序 ============
$script:fatal = $null
try {
    if ($AutoSend -eq '' -and $env:LLAMA_AUTOSEND) { $AutoSend = [string]$env:LLAMA_AUTOSEND }
    $script:cfg = Load-Config
    $script:currentModel = [string]$script:cfg.model
if ($PresetTest) {
    "whitelist: " + (@($script:effortKeywords) -join ", ")
    foreach ($m in @(Get-Models $script:cfg.model)) {
        $ok = Test-EffortAllowed ([string]$m.Path)
        '{0} => allowed={1} template={2}' -f $m.Name, $ok, $(if ($ok) { 'jinja-or-kept' } else { 'none' })
    }
    exit 0
}
    if ($SelfTest) {
        $args = Build-Arguments $script:cfg
        'args: ' + ($args -join ' ')
        'models found: ' + (Get-Models $script:cfg.model).Count
        'running: ' + (Test-EngineRunning)
        exit 0
    }
    if ($ChatTest) {
        $msgs = @([pscustomobject]@{ role = 'user'; content = $Prompt })
        $trimmed = Trim-Messages $msgs ([int]$script:cfg.ctx)
        $modelName = [IO.Path]::GetFileNameWithoutExtension([string]$script:cfg.model)
        if (-not (Test-EngineRunning)) { Write-Output 'engine not running'; exit 2 }
        $sw = [Diagnostics.Stopwatch]::StartNew()
        $j = Invoke-ChatBlocking ([int]$script:cfg.port) $modelName $trimmed 'medium' 512
        $sw.Stop()
        $m = $j.choices[0].message
        $rc = ''
        if ($null -ne $m.reasoning_content) { $rc = [string]$m.reasoning_content }
        'elapsed: ' + [math]::Round($sw.Elapsed.TotalSeconds, 1) + 's'
        'reasoning chars: ' + $rc.Length
        'answer: ' + $m.content
        'tokens: ' + $j.usage.completion_tokens
        exit 0
    }
    # ---------- 窗口 ----------
    Add-Type -Namespace 'Win32' -Name 'Api' -MemberDefinition '[DllImport("user32.dll")] public static extern IntPtr SendMessage(IntPtr hWnd, int Msg, IntPtr wParam, IntPtr lParam); [DllImport("kernel32.dll")] public static extern IntPtr GetConsoleWindow(); [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int n); [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h); [DllImport("user32.dll")] public static extern bool RedrawWindow(IntPtr h, IntPtr r, IntPtr rgn, uint flags);' -ErrorAction SilentlyContinue
    $script:baseFont = [System.Drawing.SystemFonts]::MessageBoxFont
    $script:monoFont = New-Object System.Drawing.Font('Consolas', 9.5)
    $f = New-Object System.Windows.Forms.Form
    $f.Text = 'llama.cpp 控制台'
    $f.StartPosition = 'CenterScreen'
    $f.ClientSize = New-Object System.Drawing.Size(760, 880)
 $f.MinimumSize = New-Object System.Drawing.Size(740, 620)
    $f.FormBorderStyle = 'Sizable'
    $f.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::Dpi
    $f.Font = $script:baseFont
    $f.Icon = [System.Drawing.SystemIcons]::Application
    # 底部按钮栏（左右分组，状态居中）
    $bar = New-Object System.Windows.Forms.Panel
    $bar.Dock = 'Bottom'; $bar.Height = 52; $bar.Padding = New-Object System.Windows.Forms.Padding(10, 8, 10, 8)
    $f.Controls.Add($bar)
    $barTlp = New-Object System.Windows.Forms.TableLayoutPanel
    $barTlp.Dock = 'Fill'; $barTlp.ColumnCount = 3; $barTlp.RowCount = 1
    [void]$barTlp.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::AutoSize)))
    [void]$barTlp.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100)))
    [void]$barTlp.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::AutoSize)))
    [void]$barTlp.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 100)))
    $bar.Controls.Add($barTlp)
    $flowLeft = New-Object System.Windows.Forms.FlowLayoutPanel
    $flowLeft.AutoSize = $true; $flowLeft.WrapContents = $false; $flowLeft.Dock = 'Fill'
    $flowLeft.FlowDirection = [System.Windows.Forms.FlowDirection]::LeftToRight
    $flowLeft.Margin = New-Object System.Windows.Forms.Padding(0)
    $barTlp.Controls.Add($flowLeft, 0, 0)
    $lblStatus = New-Object System.Windows.Forms.Label
    $lblStatus.AutoSize = $false; $lblStatus.Dock = 'Fill'
    $lblStatus.TextAlign = 'MiddleCenter'; $lblStatus.ForeColor = [System.Drawing.Color]::FromArgb(0, 120, 0)
    $lblStatus.Margin = New-Object System.Windows.Forms.Padding(12, 0, 12, 0)
    $barTlp.Controls.Add($lblStatus, 1, 0)
    $flowRight = New-Object System.Windows.Forms.FlowLayoutPanel
    $flowRight.AutoSize = $true; $flowRight.WrapContents = $false; $flowRight.Dock = 'Fill'
    $flowRight.FlowDirection = [System.Windows.Forms.FlowDirection]::RightToLeft
    $flowRight.Margin = New-Object System.Windows.Forms.Padding(0)
    $barTlp.Controls.Add($flowRight, 2, 0)
    $script:ui = @{ status = $lblStatus }
    function New-BarButton([string]$text, [int]$w) {
        $b = New-Object System.Windows.Forms.Button
        $b.Text = $text; $b.Width = $w; $b.Height = 30
        $b.Margin = New-Object System.Windows.Forms.Padding(0, 0, 8, 0)
        return $b
    }
    $btnStart = New-BarButton '启动服务' 96
    $btnStop = New-BarButton '停止服务' 96
    $btnSave = New-BarButton '保存配置' 96
    $btnReset = New-BarButton '重置配置' 96
    $btnSet = New-BarButton '设置...' 80
    $flowLeft.Controls.Add($btnStart); $flowLeft.Controls.Add($btnStop)
    $flowRight.Controls.Add($btnSet); $flowRight.Controls.Add($btnReset); $flowRight.Controls.Add($btnSave)
    $btnReset.Add_Click({ Reset-ToDefaults })
    $tabs = New-Object System.Windows.Forms.TabControl
    $tabs.Dock = 'Fill'
    $f.Controls.Add($tabs)
    $f.Controls.SetChildIndex($tabs, 0)
    $tabServer = New-Object System.Windows.Forms.TabPage
    $tabServer.Text = '服务设置'
    $tabs.TabPages.Add($tabServer)
    $tabChat = New-Object System.Windows.Forms.TabPage
    $tabChat.Text = '对话'
    $tabs.TabPages.Add($tabChat)
    # ---- 服务设置页 ----
    $scroll = New-Object System.Windows.Forms.Panel
    $scroll.Dock = 'Fill'; $scroll.AutoScroll = $true; $scroll.Padding = New-Object System.Windows.Forms.Padding(8)
    $tabServer.Controls.Add($scroll)
    $tlp = New-Object System.Windows.Forms.TableLayoutPanel
    $tlp.Dock = 'Top'; $tlp.AutoSize = $true; $tlp.ColumnCount = 2
    [void]$tlp.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 180)))
    [void]$tlp.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100)))
    $scroll.Controls.Add($tlp)
    $script:rows = 0
    $script:rowDefs = @{}
    $script:order = New-Object System.Collections.ArrayList
    function Add-Row([string]$label, $ctrl, [string]$key) {
        $script:rows++
        $r = $script:rows - 1
        $l = New-Object System.Windows.Forms.Label
        $l.Text = $label; $l.AutoSize = $false; $l.Width = 172; $l.Height = 24
        $l.TextAlign = 'MiddleLeft'; $l.Margin = New-Object System.Windows.Forms.Padding(0, 4, 8, 4)
        $ctrl.Dock = [System.Windows.Forms.DockStyle]::Fill
        $ctrl.Margin = New-Object System.Windows.Forms.Padding(0, 3, 0, 3)
        $ctrl.Tag = $key
        $tlp.Controls.Add($l, 0, $r)
        $tlp.Controls.Add($ctrl, 1, $r)
        [void]$tlp.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::AutoSize)))
        [void]$tlp.RowCount++
        $script:rowDefs[$key] = @{ key = $key; label = $l; ctrl = $ctrl }
        [void]$script:order.Add($key)
    }
    function Rebuild-Rows {
        $tlp.SuspendLayout()
        try {
            $tlp.Controls.Clear()
            $tlp.RowStyles.Clear()
            $tlp.RowCount = 0
            foreach ($k in @($script:order)) {
                $def = $script:rowDefs[[string]$k]
                if ($null -eq $def) { continue }
                [void]$tlp.RowCount++
                [void]$tlp.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::AutoSize)))
                $r = $tlp.RowCount - 1
                $tlp.Controls.Add($def.label, 0, $r)
                $tlp.Controls.Add($def.ctrl, 1, $r)
            }
        } finally {
            $tlp.ResumeLayout()
            $tlp.PerformLayout()
        }
    }
    function Apply-SavedLayoutOrder {
        $saved = @($script:layoutOrder)
        if ($saved.Count -gt 0) {
            $ordered = New-Object System.Collections.ArrayList
            foreach ($k in $saved) {
                if ($script:rowDefs.ContainsKey([string]$k) -and -not $ordered.Contains([string]$k)) { [void]$ordered.Add([string]$k) }
            }
            foreach ($k in @($script:order)) { if (-not $ordered.Contains([string]$k)) { [void]$ordered.Add([string]$k) } }
            $script:order = $ordered
        }
        Rebuild-Rows
    }
    function Move-Row([string]$key, [int]$delta) {
        $idx = $script:order.IndexOf([string]$key)
        if ($idx -lt 0) { return }
        $newIdx = $idx + $delta
        if ($newIdx -lt 0 -or $newIdx -ge $script:order.Count) { return }
        $script:order.RemoveAt($idx)
        $script:order.Insert($newIdx, [string]$key)
        Rebuild-Rows
        try { Save-Config (Read-Config) } catch { }
    }
    function New-Num($min, $max, $val, $dec) {
        $n = New-Object System.Windows.Forms.NumericUpDown
        $n.Minimum = $min; $n.Maximum = $max; $n.DecimalPlaces = $dec
        $v2 = [double]$val
        if ($v2 -lt [double]$min) { $v2 = [double]$min }
        if ($v2 -gt [double]$max) { $v2 = [double]$max }
        $n.Value = [decimal]$v2
        $n.ThousandsSeparator = $true
        return $n
    }
    function New-Combo([string[]]$items, [string]$sel) {
        $c = New-Object System.Windows.Forms.ComboBox
        $c.DropDownStyle = 'DropDownList'
        foreach ($i in $items) { [void]$c.Items.Add($i) }
        if ($items -contains $sel) { $c.SelectedItem = $sel } elseif ($c.Items.Count -gt 0) { $c.SelectedIndex = 0 }
        return $c
    }
    function New-Check([string]$text, [bool]$checked) {
        $k = New-Object System.Windows.Forms.CheckBox
        $k.Text = $text; $k.Checked = $checked; $k.AutoSize = $true
        return $k
    }
    function New-Text([string]$text) {
        $t = New-Object System.Windows.Forms.TextBox
        $t.Text = $text
        return $t
    }
    # 模型 + 刷新 / 浏览
    $modelPanel = New-Object System.Windows.Forms.Panel
    $modelPanel.Height = 28
    $cmbModel = New-Object System.Windows.Forms.ComboBox
    $cmbModel.DropDownStyle = 'DropDownList'; $cmbModel.DisplayMember = 'Text'; $cmbModel.ValueMember = 'Path'
    $cmbModel.Dock = 'Fill'
    $models = Get-Models $script:cfg.model
    foreach ($m in $models) { [void]$cmbModel.Items.Add($m) }
    $sel = $models | Where-Object { $_.Path -eq $script:cfg.model } | Select-Object -First 1
    if ($sel) { $cmbModel.SelectedItem = $sel } elseif ($cmbModel.Items.Count -gt 0) { $cmbModel.SelectedIndex = 0 }
    $btnRefresh = New-Object System.Windows.Forms.Button
    $btnRefresh.Text = '刷新'; $btnRefresh.Dock = 'Right'; $btnRefresh.Width = 60
    $btnBrowse = New-Object System.Windows.Forms.Button
    $btnBrowse.Text = '浏览...'; $btnBrowse.Dock = 'Right'; $btnBrowse.Width = 70
    $modelPanel.Controls.Add($cmbModel); $modelPanel.Controls.Add($btnBrowse); $modelPanel.Controls.Add($btnRefresh)
    $script:ui.model = $cmbModel
    Add-Row '模型文件' $modelPanel 'model'
    $nPort = New-Num 1024 65535 $script:cfg.port 0; $script:ui.port = $nPort; Add-Row '端口' $nPort 'port'
    $nCtx = New-Num 1024 1048576 $script:cfg.ctx 0; $script:ui.ctx = $nCtx; Add-Row '上下文长度 (tokens)' $nCtx 'ctx'
    $nNgl = New-Num 0 999 $script:cfg.ngl 0; $script:ui.ngl = $nNgl; Add-Row 'GPU 层数 (0=CPU)' $nNgl 'ngl'
    $cKv = New-Combo @('f16', 'q8_0', 'q5_1', 'q5_0', 'q4_1', 'q4_0') $script:cfg.kv; $script:ui.kv = $cKv; Add-Row 'KV 缓存精度' $cKv 'kv'
    $nThreads = New-Num 1 128 $script:cfg.threads 0; $script:ui.threads = $nThreads; Add-Row 'CPU 线程' $nThreads 'threads'
    $nParallel = New-Num 1 16 $script:cfg.parallel 0; $script:ui.parallel = $nParallel; Add-Row '并发槽位' $nParallel 'parallel'
    $nBatch = New-Num 1 8192 $script:cfg.batch 0; $script:ui.batch = $nBatch; Add-Row 'Batch 大小' $nBatch 'batch'
    $nUbatch = New-Num 1 8192 $script:cfg.ubatch 0; $script:ui.ubatch = $nUbatch; Add-Row 'Ubatch 大小' $nUbatch 'ubatch'
    $nPredict = New-Num (-1) 131072 $script:cfg.nPredict 0; $script:ui.nPredict = $nPredict; Add-Row '最大输出 tokens (-1=不限)' $nPredict 'nPredict'
    $nTemp = New-Num 0 5 $script:cfg.temp 2; $script:ui.temp = $nTemp; Add-Row '温度' $nTemp 'temp'
    $nTopP = New-Num 0 1 $script:cfg.topP 2; $script:ui.topP = $nTopP; Add-Row 'Top P' $nTopP 'topP'
    $nTopK = New-Num 0 200 $script:cfg.topK 0; $script:ui.topK = $nTopK; Add-Row 'Top K' $nTopK 'topK'
    $nMinP = New-Num 0 1 $script:cfg.minP 2; $script:ui.minP = $nMinP; Add-Row '最小 P' $nMinP 'minP'
    $nRepeat = New-Num 0 5 $script:cfg.repeatPen 2; $script:ui.repeatPen = $nRepeat; Add-Row '重复惩罚' $nRepeat 'repeatPen'
    $nSeed = New-Num (-1) 2147483647 $script:cfg.seed 0; $script:ui.seed = $nSeed; Add-Row '随机种子 (-1=随机)' $nSeed 'seed'
    $cFlash = New-Combo @('auto', 'on', 'off') $script:cfg.flash; $script:ui.flash = $cFlash; Add-Row 'Flash Attention' $cFlash 'flash'
    $ckKvUnified = New-Check '启用统一 KV 缓存' $script:cfg.kvUnified; $script:ui.kvUnified = $ckKvUnified; Add-Row 'KV 统一缓存' $ckKvUnified 'kvUnified'
    $tplPanel = New-Object System.Windows.Forms.Panel
    $tplPanel.Height = 28
    $tbTemplate = New-Object System.Windows.Forms.TextBox
    $tbTemplate.Text = [string]$script:cfg.template; $tbTemplate.Dock = 'Fill'
    $btnTpl = New-Object System.Windows.Forms.Button
    $btnTpl.Text = '浏览...'; $btnTpl.Dock = 'Right'; $btnTpl.Width = 70
    $tplPanel.Controls.Add($tbTemplate); $tplPanel.Controls.Add($btnTpl)
    $script:ui.template = $tbTemplate
    Add-Row '思考模板文件' $tplPanel 'template'
    $ckKvOffload = New-Check '开启（KV 缓存放显存，更快）' $script:cfg.kvOffload; $script:ui.kvOffload = $ckKvOffload; Add-Row 'KV 缓存放显存' $ckKvOffload 'kvOffload'
    $ckMmap = New-Check '开启（加载快、省内存）' $script:cfg.mmap; $script:ui.mmap = $ckMmap; Add-Row '内存映射 mmap' $ckMmap 'mmap'
    $ckCont = New-Check '开启（并发时连续批处理）' $script:cfg.contBatch; $script:ui.contBatch = $ckCont; Add-Row '连续批处理' $ckCont 'contBatch'
    $nThreadsBatch = New-Num 0 128 $script:cfg.threadsBatch 0; $script:ui.threadsBatch = $nThreadsBatch; Add-Row '批处理线程 (0=默认)' $nThreadsBatch 'threadsBatch'
    $tbSys = New-Text ([string]$script:cfg.systemPrompt); $tbSys.Height = 24; $script:ui.systemPrompt = $tbSys; Add-Row '系统提示词' $tbSys 'systemPrompt'
    $tbKey = New-Text ([string]$script:cfg.apiKey); $script:ui.apiKey = $tbKey; Add-Row 'API 密钥 (可空)' $tbKey 'apiKey'
    $extraPanel = New-Object System.Windows.Forms.Panel
    $extraPanel.Height = 156
    $gridExtra = New-Object System.Windows.Forms.DataGridView
    $gridExtra.BorderStyle = 'FixedSingle'
    $gridExtra.AllowUserToAddRows = $false
    $gridExtra.AllowUserToDeleteRows = $false
    $gridExtra.AllowUserToResizeRows = $false
    $gridExtra.RowHeadersVisible = $false
    $gridExtra.AutoSizeColumnsMode = 'Fill'
    $gridExtra.SelectionMode = 'FullRowSelect'
    $gridExtra.MultiSelect = $false
    $colKey = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
    $colKey.HeaderText = '参数名'
    $colKey.Name = 'key'
    $colKey.FillWeight = 60
    $colVal = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
    $colVal.HeaderText = '参数值'
    $colVal.Name = 'value'
    $colVal.FillWeight = 40
    [void]$gridExtra.Columns.Add($colKey)
    [void]$gridExtra.Columns.Add($colVal)
    $extraBtns = New-Object System.Windows.Forms.FlowLayoutPanel
    $extraBtns.Height = 28
    $extraBtns.WrapContents = $false
    $btnAddRow = New-Object System.Windows.Forms.Button
    $btnAddRow.Text = '+ 添加行'; $btnAddRow.Size = New-Object System.Drawing.Size(90, 26)
    $btnAddRow.Margin = New-Object System.Windows.Forms.Padding(0, 0, 8, 0)
    $btnDelRow = New-Object System.Windows.Forms.Button
    $btnDelRow.Text = '- 删除选中行'; $btnDelRow.Size = New-Object System.Drawing.Size(110, 26)
    $btnDelRow.Margin = New-Object System.Windows.Forms.Padding(0)
    [void]$extraBtns.Controls.Add($btnAddRow)
    [void]$extraBtns.Controls.Add($btnDelRow)
    $extraPanel.Controls.Add($gridExtra)
    $extraPanel.Controls.Add($extraBtns)
    $extraPanel.Add_Resize({
        $gridExtra.SetBounds(0, 0, $extraPanel.ClientSize.Width, [Math]::Max(60, ($extraPanel.ClientSize.Height - 30)))
        $extraBtns.SetBounds(0, ($extraPanel.ClientSize.Height - 28), $extraPanel.ClientSize.Width, 28)
    })
    $btnAddRow.Add_Click({
        $idx = $gridExtra.Rows.Add()
        $gridExtra.CurrentCell = $gridExtra.Rows[$idx].Cells[0]
        $gridExtra.Focus()
        [void]$gridExtra.BeginEdit($true)
    })
    $btnDelRow.Add_Click({
        if ($gridExtra.SelectedRows.Count -gt 0) { foreach ($r in @($gridExtra.SelectedRows)) { $gridExtra.Rows.Remove($r) } }
        elseif ($null -ne $gridExtra.CurrentRow) { $gridExtra.Rows.Remove($gridExtra.CurrentRow) }
    })
    foreach ($er in @($script:cfg.extra)) { [void]$gridExtra.Rows.Add([string]$er.key, [string]$er.value) }
    $script:ui.extra = $gridExtra
    Add-Row '其他原始参数' $extraPanel 'extra'
    # ---- 对话页 ----
    $chatTlp = New-Object System.Windows.Forms.Panel
    $chatTlp.Dock = 'Fill'; $chatTlp.Padding = New-Object System.Windows.Forms.Padding(8)
    $tabChat.Controls.Add($chatTlp)
    $topStrip = New-Object System.Windows.Forms.FlowLayoutPanel
    $topStrip.WrapContents = $false; $topStrip.Height = 34
    $lblConn = New-Object System.Windows.Forms.Label
    $lblConn.AutoSize = $true; $lblConn.Text = ''; $lblConn.Margin = New-Object System.Windows.Forms.Padding(0, 9, 10, 0)
    $lblModelTag = New-Object System.Windows.Forms.Label
    $lblModelTag.AutoSize = $true; $lblModelTag.Text = '模型'; $lblModelTag.Margin = New-Object System.Windows.Forms.Padding(0, 9, 6, 0)
    $cmbChat = New-Object System.Windows.Forms.ComboBox
    $cmbChat.DropDownStyle = 'DropDownList'
    $cmbChat.DisplayMember = 'Name'
    $cmbChat.ValueMember = 'Path'
    $cmbChat.Width = 240
    $cmbChat.Margin = New-Object System.Windows.Forms.Padding(0, 2, 10, 2)
    foreach ($m in $models) { [void]$cmbChat.Items.Add($m) }
    $selChat = $null
    foreach ($it in $cmbChat.Items) { if ([string]$it.Path -eq [string]$script:cfg.model) { $selChat = $it; break } }
    if ($null -ne $selChat) { $cmbChat.SelectedItem = $selChat } elseif ($cmbChat.Items.Count -gt 0) { $cmbChat.SelectedIndex = 0 }
$script:cmbChat = $cmbChat
    $tipChat = New-Object System.Windows.Forms.ToolTip
    $lblEffort = New-Object System.Windows.Forms.Label
    $lblEffort.AutoSize = $true; $lblEffort.Text = '思考等级'; $lblEffort.Margin = New-Object System.Windows.Forms.Padding(0, 9, 6, 0)
    $cEffort = New-Combo @('off', 'low', 'medium', 'high', 'xhigh', 'max') 'medium'
    $cEffort.Width = 110; $cEffort.Margin = New-Object System.Windows.Forms.Padding(0, 2, 8, 2)
    $btnClear = New-Object System.Windows.Forms.Button
    $btnClear.Text = '清空对话'; $btnClear.Width = 90; $btnClear.Height = 26
    $btnClear.Margin = New-Object System.Windows.Forms.Padding(0, 2, 0, 2)
    $topStrip.Controls.Add($lblConn); $topStrip.Controls.Add($lblModelTag); $topStrip.Controls.Add($cmbChat)
    $topStrip.Controls.Add($lblEffort); $topStrip.Controls.Add($cEffort); $topStrip.Controls.Add($btnClear)
    $script:ui.effort = $cEffort
    $script:syncingChat = $false
    $chatTlp.Controls.Add($topStrip)
    $history = New-Object System.Windows.Forms.RichTextBox
    $history.ReadOnly = $true; $history.BackColor = [System.Drawing.Color]::White
    $history.BorderStyle = 'FixedSingle'; $history.Font = New-Object System.Drawing.Font('Microsoft YaHei UI', 10)
    $history.WordWrap = $true
    try { $history.GetType().GetProperty('DoubleBuffered', [System.Reflection.BindingFlags]'Instance,NonPublic').SetValue($history, $true) } catch { }
    $chatTlp.Controls.Add($history)
    $inputBox = New-Object System.Windows.Forms.TextBox
    $inputBox.Multiline = $true; $inputBox.Font = $history.Font
    $inputBox.ScrollBars = 'Vertical'; $inputBox.AcceptsReturn = $true
    $chatTlp.Controls.Add($inputBox)
    $chatBtns = New-Object System.Windows.Forms.TableLayoutPanel
    $chatBtns.ColumnCount = 3; $chatBtns.RowCount = 1
    [void]$chatBtns.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::AutoSize)))
    [void]$chatBtns.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100)))
    [void]$chatBtns.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::AutoSize)))
    [void]$chatBtns.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 100)))
    $btnSend = New-Object System.Windows.Forms.Button
    $btnSend.Text = '发送 (Enter)'; $btnSend.Width = 110; $btnSend.Height = 30
    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Text = '停止'; $btnCancel.Width = 80; $btnCancel.Height = 30; $btnCancel.Enabled = $false
    $btnImg = New-Object System.Windows.Forms.Button
    $btnImg.Text = '图片...'; $btnImg.Width = 80; $btnImg.Height = 30
    $lblChat = New-Object System.Windows.Forms.Label
    $lblChat.AutoSize = $true; $lblChat.TextAlign = 'MiddleLeft'; $lblChat.Margin = New-Object System.Windows.Forms.Padding(10, 10, 0, 0)
    $chatLeft = New-Object System.Windows.Forms.FlowLayoutPanel
    $chatLeft.AutoSize = $true; $chatLeft.AutoSizeMode = 'GrowAndShrink'; $chatLeft.WrapContents = $false
    $chatLeft.Margin = New-Object System.Windows.Forms.Padding(0); $chatLeft.Anchor = 'Left'
    $chatLeft.Controls.Add($btnImg); $chatLeft.Controls.Add($btnCancel); $chatLeft.Controls.Add($lblChat)
    $btnSend.Anchor = 'Right'; $btnSend.Margin = New-Object System.Windows.Forms.Padding(8, 8, 0, 8)
    $chatBtns.Controls.Add($chatLeft, 0, 0); $chatBtns.Controls.Add($btnSend, 2, 0)
    $chatTlp.Controls.Add($chatBtns)
    function Update-ChatLayout {
        if ($null -eq $chatTlp -or $chatTlp.ClientSize.Width -le 0) { return }
        $w = $chatTlp.ClientSize.Width; $h = $chatTlp.ClientSize.Height
        $topStrip.SetBounds(8, 8, ($w - 16), 34)
        $cmbChat.Width = [Math]::Max(140, [Math]::Min(340, ($w - 540)))
        $btnY = $h - 8 - 46
        $inpY = $btnY - 6 - 90
        $histY = 48
        if ($inpY -lt ($histY + 40)) { $inpY = $histY + 40 }
        $histH = [Math]::Max(40, ($inpY - 6 - $histY))
        $history.SetBounds(8, $histY, ($w - 16), $histH)
        $inputBox.SetBounds(8, $inpY, ($w - 16), 90)
        $chatBtns.SetBounds(8, $btnY, ($w - 16), 46)
    }
    $chatTlp.Add_SizeChanged({ Update-ChatLayout })
    # ---- 状态 / 共享 ----
    $script:msgs = New-Object System.Collections.ArrayList
    $script:imgData = ''
    $script:lastAnswer = ''
    $script:client = New-Object System.Net.Http.HttpClient
    $script:client.Timeout = [TimeSpan]::FromMinutes(30)
    $script:task = $null
    $script:busy = $false
    $script:timer = New-Object System.Windows.Forms.Timer
    $script:timer.Interval = 250
    function Read-Config {
        $c = [ordered]@{}
        if ($null -ne $script:cfg) { foreach ($k in $script:cfg.Keys) { $c[$k] = $script:cfg[$k] } }
        foreach ($k in $script:DefaultConfig.Keys) { if (-not $c.Contains($k)) { $c[$k] = $script:DefaultConfig[$k] } }
        if ($script:ui.model.SelectedItem) { $c.model = $script:ui.model.SelectedItem.Path }
        $c.port = [int]$script:ui.port.Value
        $c.ctx = [int]$script:ui.ctx.Value
        $c.ngl = [int]$script:ui.ngl.Value
        $c.kv = [string]$script:ui.kv.SelectedItem
        $c.threads = [int]$script:ui.threads.Value
        $c.parallel = [int]$script:ui.parallel.Value
        $c.batch = [int]$script:ui.batch.Value
        $c.ubatch = [int]$script:ui.ubatch.Value
        $c.nPredict = [int]$script:ui.nPredict.Value
        $c.seed = [long]$script:ui.seed.Value
        $c.temp = [double]$script:ui.temp.Value
        $c.topP = [double]$script:ui.topP.Value
        $c.topK = [int]$script:ui.topK.Value
        $c.minP = [double]$script:ui.minP.Value
        $c.repeatPen = [double]$script:ui.repeatPen.Value
        $c.flash = [string]$script:ui.flash.SelectedItem
        $c.kvUnified = [bool]$script:ui.kvUnified.Checked
        $c.template = ([string]$script:ui.template.Text).Trim()
        $c.kvOffload = [bool]$script:ui.kvOffload.Checked
        $c.mmap = [bool]$script:ui.mmap.Checked
        $c.contBatch = [bool]$script:ui.contBatch.Checked
        $c.threadsBatch = [int]$script:ui.threadsBatch.Value
            $c.reasoningBudget = $(if ($null -ne $script:ui.reasoningBudget) { [int]$script:ui.reasoningBudget.Value } else { [int]$script:cfg['reasoningBudget'] })
        $c.effort = $(if ($script:ui.effort.Enabled) { [string]$script:ui.effort.SelectedItem } else { 'off' })
        $c.systemPrompt = [string]$script:ui.systemPrompt.Text
        $c.apiKey = [string]$script:ui.apiKey.Text
        $c.extra = @(Get-ExtraRows)
        return $c
    }
    function Update-Status {
            if ($script:saveFlash -and $script:saveFlash.Enabled) { return }
        try {
            $running = Test-EngineRunning
            $port = [int]$script:ui.port.Value
            if ($running) {
                $ready = $false
                try { $r = Invoke-WebRequest -Uri ('http://127.0.0.1:' + $port + '/health') -UseBasicParsing -TimeoutSec 2; if ($r.StatusCode -eq 200) { $ready = $true } } catch { }
                if ($ready) { $script:ui.status.Text = '运行中  端口 ' + $port + ' 就绪'; $script:ui.status.ForeColor = [System.Drawing.Color]::FromArgb(0, 128, 0) }
                else { $script:ui.status.Text = '运行中  端口 ' + $port + ' 启动中...'; $script:ui.status.ForeColor = [System.Drawing.Color]::FromArgb(180, 110, 0) }
            } else {
                $script:ui.status.Text = '未启动'; $script:ui.status.ForeColor = [System.Drawing.Color]::FromArgb(120, 120, 120)
            }
            $lblConn.Text = '端口 ' + $port
            $cur = $script:ui.model.SelectedItem
            if ($null -ne $cur) {
                $script:syncingChat = $true
                try {
                    foreach ($it in $cmbChat.Items) { if ([string]$it.Path -eq [string]$cur.Path) { $cmbChat.SelectedItem = $it; break } }
                } finally { $script:syncingChat = $false }
                $tipChat.SetToolTip($cmbChat, [string]$cur.Path)
            }
        } catch { }
    }
    function Clear-Chat {
        $script:msgs.Clear()
        $history.Clear()
        $script:lastAnswer = ''
        $script:imgData = ''
        $inputBox.Text = ''
        $lblChat.Text = '就绪'
    }
    # 聊天页切换模型：运行中则确认后重启服务，并清空上下文，防止串模型污染
    $cmbModel.Add_SelectedIndexChanged({
        if ($script:switchingModel) { return }
        if ($null -eq $script:ui.template) { return }
        try {
            $item = $script:ui.model.SelectedItem
            if ($null -eq $item) { return }
            $newPath = [string]$item.Path
            $oldModel = [string]$script:currentModel
            if ($oldModel -eq '') { $oldModel = [string]$script:cfg.model }
            if ($newPath -eq $oldModel) { return }
            $cur = Read-Config
            $cur['model'] = $oldModel
            $script:modelConfigs[$oldModel] = Get-PerModelBlock $cur
            $next = New-DefaultConfigForModel $newPath $cur['port']
            if ($script:modelConfigs.ContainsKey($newPath)) { $next = Apply-PerModelBlock $next $script:modelConfigs[$newPath] }
            $script:cfg = $next
            Set-UiFromConfig $next
            Save-Config (Read-Config)
            $lblChat.Text = '已切换模型：' + [string]$item.Name
        } catch { Show-Fatal '切换模型配置' $_ }
    })
    $cmbChat.Add_SelectedIndexChanged({
        if ($script:syncingChat) { return }
        try {
            if ($script:busy) {
                [void][System.Windows.Forms.MessageBox]::Show('正在等待模型回复，请先点「停止」或等回复完成后再切换模型。', '切换模型')
                $script:syncingChat = $true
                try {
                    $old = $script:ui.model.SelectedItem
                    if ($null -ne $old) { foreach ($it in $cmbChat.Items) { if ([string]$it.Path -eq [string]$old.Path) { $cmbChat.SelectedItem = $it; break } } }
                } finally { $script:syncingChat = $false }
                return
            }
            $item = $cmbChat.SelectedItem
            if ($null -eq $item) { return }
            $newPath = [string]$item.Path
            $oldPath = [string]$script:currentModel
            if ($oldPath -eq '') { $oldPath = [string]$script:cfg.model }
            if ($newPath -eq $oldPath) { return }
            $wasRunning = Test-EngineRunning
            if ($wasRunning) {
                $msg = '切换模型需要重启服务。' + [Environment]::NewLine + [Environment]::NewLine + '继续会先停止服务、换模型再启动，并清空当前聊天记录和上下文。是否继续？'
                $answer = [System.Windows.Forms.MessageBox]::Show($msg, '切换模型', 'YesNo', 'Question')
                if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) {
                    $script:syncingChat = $true
                    try { foreach ($it in $cmbChat.Items) { if ([string]$it.Path -eq $oldPath) { $cmbChat.SelectedItem = $it; break } } } finally { $script:syncingChat = $false }
                    return
                }
            }
            $lblChat.Text = '正在切换模型...'
            if ($wasRunning) { Stop-Engine; Start-Sleep -Milliseconds 800 }
            $cur = Read-Config
            $cur['model'] = $oldPath
            $script:modelConfigs[$oldPath] = Get-PerModelBlock $cur
            $next = New-DefaultConfigForModel $newPath $cur['port']
            if ($script:modelConfigs.ContainsKey($newPath)) { $next = Apply-PerModelBlock $next $script:modelConfigs[$newPath] }
            $script:cfg = $next
            Set-UiFromConfig $next
            Clear-Chat
            Save-Config (Read-Config)
            if ($wasRunning) { Start-Engine (Read-Config) }
            $lblChat.Text = '已切换模型：' + [string]$item.Name
            Update-Status
        } catch { Show-Fatal '切换模型' $_ }
    })
    $statusTimer = New-Object System.Windows.Forms.Timer
    $statusTimer.Interval = 2000
    $statusTimer.Add_Tick({ Update-Status })
    $statusTimer.Start()
    $script:saveFlash = New-Object System.Windows.Forms.Timer
    $script:saveFlash.Interval = 3000
    $script:saveFlash.Add_Tick({ $script:saveFlash.Stop(); Update-Status })
    # ---- 按钮事件 ----
    $btnStart.Add_Click({
        try {
            $conf = Read-Config
            $modelChanged = ($script:loadedModel -ne '') -and ([string]$conf.model -ne $script:loadedModel)
            if (Test-EngineRunning) {
                if ($modelChanged) {
                    $ans = [System.Windows.Forms.MessageBox]::Show("模型已更改，需要重启服务才能生效，并会清空当前聊天记录。`n`n是否立即重启？", '启动服务', [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Question)
                    if ($ans -eq [System.Windows.Forms.DialogResult]::Yes) {
                        Stop-Engine
                        Start-Sleep -Milliseconds 800
                        Clear-Chat
                        if (-not (Start-Engine $conf)) {
                            $lblChat.Text = '启动失败：请检查【设置】中的引擎路径'
                            $statusTimer.Stop()
                        } else {
                            $lblChat.Text = '模型已更换，聊天记录已清空，正在重启服务...'
                            $statusTimer.Start()
                        }
                    }
                } else {
                    [void][System.Windows.Forms.MessageBox]::Show('服务已经在运行了。', '提示')
                }
                return
            }
            if ($modelChanged) {
                Clear-Chat
                $lblChat.Text = '模型已更换，聊天记录已清空'
            }
            if (-not (Start-Engine $conf)) {
                $lblChat.Text = '启动失败：请检查【设置】中的引擎路径'
                return
            }
            $lblChat.Text = '正在启动服务...'
            $statusTimer.Start()
        } catch { Show-Fatal '启动服务' $_ }
    })
    $btnStop.Add_Click({
        try { Stop-Engine; Update-Status } catch { Show-Fatal '停止服务' $_ }
    })
    $btnSave.Add_Click({
        try {
            Save-Config (Read-Config)
            $lblChat.Text = '配置已保存'
            $lblStatus.Text = '✔ 配置已保存'
            $lblStatus.ForeColor = [System.Drawing.Color]::FromArgb(0, 150, 0)
            $script:saveFlash.Stop(); $script:saveFlash.Start()
        } catch { Show-Fatal '保存配置' $_ }
    })
    $btnSet.Add_Click({
        try {
            $d = New-Object System.Windows.Forms.Form
            $d.Text = '设置'; $d.ClientSize = New-Object System.Drawing.Size(440, 380)
            $d.StartPosition = 'CenterParent'; $d.FormBorderStyle = 'FixedDialog'
            $d.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::Dpi; $d.Font = $script:baseFont
            $d.MaximizeBox = $false; $d.MinimizeBox = $false
            $ckAuto = New-Check '开机自动启动' (Test-Autostart)
            $ckAuto.Location = New-Object System.Drawing.Point(18, 18); $d.Controls.Add($ckAuto)
            $bUpd = New-Object System.Windows.Forms.Button
            $bUpd.Text = '检查更新...'; $bUpd.SetBounds(18, 56, 120, 30); $d.Controls.Add($bUpd)
            $bUpd.Add_Click({ Start-Process -FilePath powershell.exe -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File', (Join-Path $script:root '升级.ps1')) })
            $bDir = New-Object System.Windows.Forms.Button
            $bDir.Text = '打开程序目录'; $bDir.SetBounds(150, 56, 120, 30); $d.Controls.Add($bDir)
            $bDir.Add_Click({ Start-Process explorer.exe $script:root })
            $bLog = New-Object System.Windows.Forms.Button
            $bLog.Text = '查看日志'; $bLog.SetBounds(282, 56, 120, 30); $d.Controls.Add($bLog)
            $bLog.Add_Click({ if (Test-Path -LiteralPath $script:serverLog) { Start-Process notepad.exe $script:serverLog } else { [void][System.Windows.Forms.MessageBox]::Show('还没有日志文件，先启动一次服务。', '提示') } })
$bWL = New-Object System.Windows.Forms.Button
            $bWL.Text = '配置思考白名单...'; $bWL.SetBounds(18, 96, 160, 30); $d.Controls.Add($bWL)
            $bWL.Add_Click({
                try {
                    $w = New-Object System.Windows.Forms.Form
                    $w.Text = '配置思考白名单'; $w.ClientSize = New-Object System.Drawing.Size(496, 484)
                    $w.StartPosition = 'CenterParent'; $w.FormBorderStyle = 'FixedDialog'
                    $w.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::Dpi; $w.Font = $script:baseFont
                    $w.MaximizeBox = $false; $w.MinimizeBox = $false

                    $jinja = Get-AutoTemplatePath
                    $generic = (Join-Path $script:root 'auto_generic_effort.jinja')
                    $models = @(Get-Models ([string]$script:cfg['model']))

                    $grid = New-Object System.Windows.Forms.DataGridView
                    $grid.SetBounds(12, 12, 472, 300)
                    $grid.AllowUserToAddRows = $false
                    $grid.AllowUserToDeleteRows = $false
                    $grid.AllowUserToResizeRows = $false
                    $grid.RowHeadersVisible = $false
                    $grid.SelectionMode = 'FullRowSelect'
                    $grid.EditMode = 'EditProgrammatically'
                    $grid.MultiSelect = $false
                    $grid.AutoSizeColumnsMode = 'Fill'
                    $grid.BorderStyle = 'FixedSingle'
                    $grid.BackgroundColor = [System.Drawing.Color]::White
                    $grid.ColumnHeadersHeightSizeMode = 'DisableResizing'
                    $w.Controls.Add($grid)

                    $colChk = New-Object System.Windows.Forms.DataGridViewCheckBoxColumn
                    $colChk.Name = 'chk'; $colChk.HeaderText = '启用'; $colChk.FillWeight = 34
                    $colChk.SortMode = 'NotSortable'
                    $colName = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
                    $colName.Name = 'name'; $colName.HeaderText = '模型名称'; $colName.FillWeight = 200
                    $colName.ReadOnly = $true; $colName.SortMode = 'NotSortable'
                    $colTpl = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
                    $colTpl.Name = 'tpl'; $colTpl.HeaderText = '模板状态'; $colTpl.FillWeight = 120
                    $colTpl.ReadOnly = $true; $colTpl.SortMode = 'NotSortable'
                    [void]$grid.Columns.Add($colChk); [void]$grid.Columns.Add($colName); [void]$grid.Columns.Add($colTpl)

                    $bBind = New-Object System.Windows.Forms.Button; $bBind.Text = '为选中模型绑定模板'; $bBind.SetBounds(12, 318, 160, 28)
                    $bClr = New-Object System.Windows.Forms.Button; $bClr.Text = '清除绑定'; $bClr.SetBounds(180, 318, 90, 28)
                    $w.Controls.Add($bBind); $w.Controls.Add($bClr)
                    $bBind.Add_Click({
                        $row = $grid.CurrentRow
                        if ($null -eq $row) { $lblMsg.Text = '请先在表格里选中一个模型'; return }
                        $p2 = [string]$row.Tag
                        $dlg2 = New-Object System.Windows.Forms.OpenFileDialog
                        $dlg2.Title = '选择思考模板'; $dlg2.Filter = 'Jinja 模板 (*.jinja)|*.jinja'
                        if ($dlg2.ShowDialog($w) -ne [System.Windows.Forms.DialogResult]::OK) { return }
                        if (-not $script:modelConfigs.ContainsKey($p2)) { $script:modelConfigs[$p2] = [ordered]@{} }
                        $script:modelConfigs[$p2]['template'] = $dlg2.FileName
                        Update-WlRow $row
                        $lblMsg.Text = '已绑定模板：' + [IO.Path]::GetFileName($dlg2.FileName)
                    })
                    $bClr.Add_Click({
                        $row = $grid.CurrentRow
                        if ($null -eq $row) { $lblMsg.Text = '请先在表格里选中一个模型'; return }
                        $p2 = [string]$row.Tag
                        if ($script:modelConfigs.ContainsKey($p2)) { $script:modelConfigs[$p2]['template'] = '' }
                        Update-WlRow $row
                        $nm0 = [string]$row.Cells[1].Value; $sn0 = $nm0; if ($sn0.Length -gt 18) { $sn0 = $sn0.Substring(0, 18) + '...' }; $lblMsg.Text = '已清除模板绑定：' + $sn0
                    })
                    $lblMsg = New-Object System.Windows.Forms.TextBox
                    $lblMsg.Multiline = $true; $lblMsg.ReadOnly = $true; $lblMsg.BorderStyle = 'None'; $lblMsg.ScrollBars = 'None'
                    $lblMsg.BackColor = $w.BackColor; $lblMsg.ForeColor = [System.Drawing.Color]::FromArgb(200, 120, 0)
                    $lblMsg.SetBounds(12, 352, 472, 44)
                    $w.Controls.Add($lblMsg)
                    $lblHint = New-Object System.Windows.Forms.Label
                    $lblHint.SetBounds(12, 400, 472, 34)
                    $lblHint.ForeColor = [System.Drawing.Color]::FromArgb(110, 110, 110)
                    $lblHint.Text = '* 未配置模板的模型将自动生成并使用通用兜底模板，配合底层推理预算（Reasoning Budget）可实现思考控制。'
                    $w.Controls.Add($lblHint)

                    $bOk = New-Object System.Windows.Forms.Button; $bOk.Text = '保存并应用'; $bOk.SetBounds(286, 444, 110, 30)
                    $bCancel = New-Object System.Windows.Forms.Button; $bCancel.Text = '取消'; $bCancel.SetBounds(402, 444, 84, 30)
                    $bCancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
                    $w.Controls.Add($bOk); $w.Controls.Add($bCancel); $w.CancelButton = $bCancel

                    function Update-WlRow($row) {
                        $path = [string]$row.Tag
                        $on = [bool]$row.Cells[0].Value
                        $tpl = ''
                        if ($script:modelConfigs.ContainsKey($path)) { $tpl = [string]$script:modelConfigs[$path]['template'] }
                        if (-not $on) {
                            $row.Cells[2].Value = '未启用'
                            $row.Cells[2].Style.ForeColor = [System.Drawing.Color]::FromArgb(140, 140, 140)
                        } elseif ((-not [string]::IsNullOrWhiteSpace($tpl)) -and ($tpl -eq (Join-Path $script:root 'auto_generic_effort.jinja'))) {
                            $row.Cells[2].Value = '已配置自动模板'
                            $row.Cells[2].Style.ForeColor = [System.Drawing.Color]::FromArgb(0, 100, 160)
                        } elseif (-not [string]::IsNullOrWhiteSpace($tpl)) {
                            $row.Cells[2].Value = '已配置模板'
                            $row.Cells[2].Style.ForeColor = [System.Drawing.Color]::FromArgb(0, 120, 0)
                        } else {
                            $row.Cells[2].Value = '⚠️ 缺少模板'
                            $row.Cells[2].Style.ForeColor = [System.Drawing.Color]::Red
                        }
                    }

                    foreach ($m in $models) {
                        $path = [string]$m.Path
                        $nm = [string]$m.Name
                        $allowed = Test-EffortAllowed $path
                        $idx = $grid.Rows.Add(@($allowed, $nm, ''))
                        $grid.Rows[$idx].Tag = $path
                        $nmLow2 = $nm.ToLowerInvariant(); if ($nmLow2.Contains('deepseek') -or $nmLow2.Contains('r1')) { $grid.Rows[$idx].Cells[0].ReadOnly = $true; $grid.Rows[$idx].Cells[0].Style.BackColor = [System.Drawing.Color]::FromArgb(238, 238, 238); $grid.Rows[$idx].Cells[0].ToolTipText = '原生思考模型无需配置' }
                        Update-WlRow $grid.Rows[$idx]
                    }


                    $grid.Add_CurrentCellDirtyStateChanged({
                        if ($grid.IsCurrentCellDirty -and $grid.CurrentCell -and $grid.CurrentCell.ColumnIndex -eq 0) {
                            $grid.CommitEdit([System.Windows.Forms.DataGridViewDataErrorContexts]::Commit)
                        }
                    })

                    $grid.Add_CellValueChanged({
                        param($snd, $ev)
                        if ($ev.RowIndex -lt 0 -or $ev.ColumnIndex -ne 0) { return }
                        $row = $grid.Rows[$ev.RowIndex]
                        $path = [string]$row.Tag
                        $nm = [string]$row.Cells[1].Value
                        $shortName = $nm; if ($shortName.Length -gt 18) { $shortName = $shortName.Substring(0, 18) + '...' }
                        $on = [bool]$row.Cells[0].Value
                        if (-not $script:modelConfigs.ContainsKey($path)) { $script:modelConfigs[$path] = [ordered]@{} }
                        $blk = $script:modelConfigs[$path]
                        if ($on) {
                            if ([string]::IsNullOrWhiteSpace([string]$blk['template'])) {
                                if ($jinja -ne '' -and $nm.ToLower().Contains('qwen') -and -not ($nm.ToLower().Contains('deepseek') -or $nm.ToLower().Contains('r1'))) { $blk['template'] = $jinja }
                                else { $blk['template'] = (Get-GenericTemplatePath) }
                            }
                            Update-WlRow $row
                            if ([string]::IsNullOrWhiteSpace([string]$blk['template'])) {
                                $lblMsg.Text = '该模型已加入白名单，但缺少模板文件，请前往服务设置页手动添加，否则拉条无法生效：' + $shortName
                            } else {
                                if (([string]$blk['template']) -eq $generic) { $lblMsg.Text = '已加入：' + $shortName + '（已自动生成通用兜底模板 auto_generic_effort.jinja）' } else { $lblMsg.Text = '已加入：' + $shortName + '（模板已就绪）' }
                            }
                        } else {
                            if ($jinja -ne '' -and ([string]$blk['template']) -eq $jinja) { $blk['template'] = '' } elseif (([string]$blk['template']) -eq $generic) { $blk['template'] = '' }
                            Update-WlRow $row
                            $lblMsg.Text = '已移出：' + $shortName
                        }
                    })

                    $bOk.Add_Click({
                        try {
                            $names = @()
                            foreach ($row in $grid.Rows) {
                                $path = [string]$row.Tag
                                $nm = [string]$row.Cells[1].Value
                                $on = [bool]$row.Cells[0].Value
                                if ($on) { $names += (Get-SeriesKeyword $nm) }
                                elseif ($script:modelConfigs.ContainsKey($path)) {
                                    $blk = $script:modelConfigs[$path]
                                    if ($jinja -ne '' -and ([string]$blk['template']) -eq $jinja) { $blk['template'] = '' } elseif (([string]$blk['template']) -eq $generic) { $blk['template'] = '' }
                                }
                            }
                            $final = @()
                            foreach ($n0 in $names) { if ($n0 -ne '' -and -not ($final -contains $n0)) { $final += $n0 } }
                            foreach ($old0 in @($script:effortKeywords)) {
                                $o0 = ([string]$old0).Trim()
                                if ($o0 -eq '' -or ($final -contains $o0)) { continue }
                                $hitChecked = $false; $hitAny = $false
                                foreach ($row2 in $grid.Rows) {
                                    $n2 = [string]$row2.Cells[1].Value
                                    if ($n2.ToLowerInvariant().Contains($o0.ToLowerInvariant())) {
                                        $hitAny = $true
                                        if ([bool]$row2.Cells[0].Value) { $hitChecked = $true }
                                    }
                                }
                                if ($hitChecked -or (-not $hitAny)) { $final += $o0 }
                            }
                            $script:effortKeywords = $final
                            Apply-EffortPolicy ([string]$script:cfg['model'])
                            Save-Config (Read-Config)
                            $lblChat.Text = '思考白名单已保存：' + ($(if ($final.Count -gt 0) { $final -join ', ' } else { '（空）' }))
                            $w.DialogResult = [System.Windows.Forms.DialogResult]::OK; $w.Close()
                        } catch { Show-Fatal '保存思考白名单' $_ }
                    })

                    [void]$w.ShowDialog($d)
                } catch { Show-Fatal '思考白名单' $_ }
            })
            $lblEng = New-Object System.Windows.Forms.Label
            $lblEng.Text = '引擎路径 (llama-server.exe)'; $lblEng.SetBounds(18, 140, 260, 20); $d.Controls.Add($lblEng)
            $tbEng = New-Object System.Windows.Forms.TextBox
            $tbEng.SetBounds(18, 162, 300, 24); $tbEng.Text = [string]$script:cfg['engineExe']; $d.Controls.Add($tbEng)
            $bEng = New-Object System.Windows.Forms.Button
            $bEng.Text = '浏览...'; $bEng.SetBounds(330, 160, 90, 26); $d.Controls.Add($bEng)
            $bEng.Add_Click({
                $pick = Select-File 'llama-server.exe|llama-server.exe|可执行文件 (*.exe)|*.exe' '选择引擎文件'
                if ($pick) { $tbEng.Text = $pick }
            })
            $bOk = New-Object System.Windows.Forms.Button
            $bOk.Text = '关闭'; $bOk.SetBounds(320, 320, 90, 30)
            $d.Controls.Add($bOk); $d.AcceptButton = $bOk
            $bOk.Add_Click({
                $newExe = [string]$tbEng.Text
                if ($newExe -eq '') { $d.Close(); return }
                if ($newExe -ne '' -and -not (Test-Path -LiteralPath $newExe)) {
                    [void][System.Windows.Forms.MessageBox]::Show('指定的引擎文件不存在，请重新选择。', '提示')
                    return
                }
                if ($newExe -ne [string]$script:cfg['engineExe']) {
                    $script:cfg['engineExe'] = $newExe
                    try { Save-Config (Read-Config) } catch { Show-Fatal '保存引擎路径' $_ }
                }
                try { Set-Autostart ([bool]$ckAuto.Checked) } catch { Show-Fatal '开机自启' $_ }
                $d.Close()
            })
            # 点右上角 X 时也保存（不弹框，仅静默保存 + 写日志）
            $d.Add_FormClosed({
                $newExe = [string]$tbEng.Text
                if ($newExe -eq '') { return }
                if ($newExe -ne '' -and -not (Test-Path -LiteralPath $newExe)) {
                    Write-UiLog ('引擎路径无效，未保存: ' + $newExe)
                    return
                }
                if ($newExe -ne [string]$script:cfg['engineExe']) {
                    $script:cfg['engineExe'] = $newExe
                    try { Save-Config (Read-Config) } catch { Write-UiLog ('保存引擎路径失败: ' + $_.Exception.Message) }
                }
            })
            [void]$d.ShowDialog($f)
        } catch { Show-Fatal '设置' $_ }
    })
    $btnRefresh.Add_Click({
        try {
            $cur = ''
            if ($script:ui.model.SelectedItem) { $cur = $script:ui.model.SelectedItem.Path }
            $list = Get-Models $cur -NoCache
            $script:ui.model.Items.Clear()
            foreach ($m in $list) { [void]$script:ui.model.Items.Add($m) }
            $s = $list | Where-Object { $_.Path -eq $cur } | Select-Object -First 1
            if ($s) { $script:ui.model.SelectedItem = $s } elseif ($script:ui.model.Items.Count -gt 0) { $script:ui.model.SelectedIndex = 0 }
            Sync-ChatModels
            $lblChat.Text = '已刷新模型列表：' + $list.Count + ' 个'
        } catch { Show-Fatal '刷新模型' $_ }
    })
    $btnBrowse.Add_Click({
        try {
            $path = Select-File 'GGUF 模型 (*.gguf)|*.gguf' '选择 GGUF 模型'
            if ($path) {
        $item = [pscustomobject]@{ Text = ('{0}  [{1} GB]' -f [IO.Path]::GetFileNameWithoutExtension($path), [math]::Round((Get-Item -LiteralPath $path).Length / 1GB, 1)); Name = [IO.Path]::GetFileNameWithoutExtension($path); Size = [math]::Round((Get-Item -LiteralPath $path).Length / 1GB, 1); Path = $path }
                [void]$script:ui.model.Items.Insert(0, $item)
                $script:ui.model.SelectedIndex = 0
                Sync-ChatModels
            }
        } catch { Show-Fatal '选择模型' $_ }
    })
    $btnTpl.Add_Click({
        try {
            $path = Select-File '模板 (*.jinja;*.txt)|*.jinja;*.txt|所有文件 (*.*)|*.*' '选择思考模板'
            if ($path) { $script:ui.template.Text = $path }
        } catch { Show-Fatal '选择模板' $_ }
    })
    # ---- 对话事件 ----
    $inputBox.Add_KeyDown({
        param($s, $e)
        if ($e.KeyCode -eq [System.Windows.Forms.Keys]::Enter -and -not $e.Shift) { $e.SuppressKeyPress = $true; $btnSend.PerformClick() }
    })
    $btnClear.Add_Click({ Clear-Chat })
    $btnImg.Add_Click({
        try {
            $path = Select-File '图片 (*.png;*.jpg;*.jpeg;*.webp;*.bmp)|*.png;*.jpg;*.jpeg;*.webp;*.bmp' '选择图片'
            if ($path) {
                $bytes = [IO.File]::ReadAllBytes($path)
                $ext = [IO.Path]::GetExtension($path).TrimStart('.').ToLower()
                if ($ext -eq 'jpg') { $ext = 'jpeg' }
                $script:imgData = 'data:image/' + $ext + ';base64,' + [Convert]::ToBase64String($bytes)
                $lblChat.Text = '已附加图片：' + [IO.Path]::GetFileName($path)
            }
        } catch { Show-Fatal '加载图片' $_ }
    })
    function Append-Msg([string]$who, [string]$text, $color) {
        $history.SelectionStart = $history.TextLength; $history.SelectionLength = 0
        $history.SelectionFont = (New-Object System.Drawing.Font($script:baseFont, [System.Drawing.FontStyle]::Bold))
        $history.SelectionColor = $color
        $history.AppendText($who + "`r`n")
        Add-Markdown $history $text $history.Font ([System.Drawing.Color]::FromArgb(30, 30, 30))
        $history.AppendText("`r`n")
        $history.SelectionStart = $history.TextLength
        $history.SelectionLength = 0
        $history.SelectionBackColor = [System.Drawing.Color]::White
        Repaint-Text $history
    }
    $btnSend.Add_Click({
        try {
            if ($script:busy) { return }
            if (-not (Test-EngineRunning)) {
                Append-Msg '系统' '服务未启动，请先点左下角「启动服务」（或等它启动完成）再发送。' ([System.Drawing.Color]::DarkOrange)
                return
            }
            if ((Test-EngineRunning) -and ($script:startedSignature -ne '')) {
                $curSig = (Get-ConfigSignature (Read-Config))
                if ($curSig -ne $script:startedSignature) {
                    $m = '参数或模型已修改，必须重启服务才能生效。' + [Environment]::NewLine + [Environment]::NewLine + '是否立即自动重启？'
                    $ans = [System.Windows.Forms.MessageBox]::Show($m, '需要重启服务', 'YesNo', 'Question')
                    if ($ans -ne [System.Windows.Forms.DialogResult]::Yes) { return }
                    $oldModel = $script:loadedModel
                    $conf2 = Read-Config
                    Stop-Engine
                    Start-Sleep -Milliseconds 900
                    if ([string]$conf2.model -ne $oldModel) { Clear-Chat }
                    Start-Engine $conf2
                    $lblChat.Text = '服务已按新配置重启，请重新发送'
                    return
                }
            }
            $text = $inputBox.Text.Trim()
            if ($text -eq '' -and $script:imgData -eq '') { return }
            $inputBox.Clear()
            if ($script:imgData -ne '') {
                $content = @(@{ type = 'text'; text = $text }, @{ type = 'image_url'; image_url = @{ url = $script:imgData } })
                [void]$script:msgs.Add([pscustomobject]@{ role = 'user'; content = $content })
                Append-Msg '你' ($text + '  [图片]') ([System.Drawing.Color]::FromArgb(0, 80, 170))
                $script:imgData = ''
            } else {
                [void]$script:msgs.Add([pscustomobject]@{ role = 'user'; content = $text })
                Append-Msg '你' $text ([System.Drawing.Color]::FromArgb(0, 80, 170))
            }
            $effForTokens = $(if ($script:ui.effort.Enabled) { [string]$script:ui.effort.SelectedItem } else { 'medium' })
            if ($effForTokens -in @('high', 'xhigh', 'max')) { $script:maxTokens = 8192 } else { $script:maxTokens = 2048 }
            $budget = [int]$script:ui.ctx.Value
            $send = Trim-Messages @($script:msgs) $budget
            $sysNow = ([string]$script:ui.systemPrompt.Text).Trim()
            if ($sysNow -ne '') { $send = @([pscustomobject]@{ role = 'system'; content = $sysNow }) + @($send) }
    $sel = $script:ui.model.SelectedItem
    $selPath = [string]$script:cfg.model
    if ($null -ne $sel -and $null -ne $sel.PSObject.Properties['Path']) { $selPath = [string]$sel.Path }
    $modelName = [IO.Path]::GetFileNameWithoutExtension($selPath)
            $bodyHash = @{
                model = $modelName
                messages = @($send)
                max_tokens = $script:maxTokens
                temperature = [double]$script:ui.temp.Value
            }
            $tplNow = ([string]$script:ui.template.Text).Trim()
            if ((Test-EffortAllowed $selPath) -and $tplNow -ne '') {
                $effSel = [string]$script:ui.effort.SelectedItem
                if ($effSel -eq '') { $effSel = 'medium' }
                $bodyHash['chat_template_kwargs'] = @{ enable_thinking = ($effSel -ne 'off'); reasoning_effort = $effSel }
            }
            $body = $bodyHash | ConvertTo-Json -Depth 12 -Compress
            $port = [int]$script:ui.port.Value
            $uri = 'http://127.0.0.1:' + $port + '/v1/chat/completions'
            $req = New-Object System.Net.Http.HttpRequestMessage([System.Net.Http.HttpMethod]::Post, $uri)
            $req.Content = New-Object System.Net.Http.StringContent($body, [System.Text.Encoding]::UTF8, 'application/json')
            if (-not (Test-EngineRunning)) { $lblChat.Text = '服务已停止'; return }
            $script:busy = $true
            $btnSend.Enabled = $false; $btnCancel.Enabled = $true
            $lblChat.Text = '等待回复...'
            $script:startTime = (Get-Date)
            $script:task = $script:client.SendAsync($req)
            $script:timer.Start()
        } catch { $script:busy = $false; $btnSend.Enabled = $true; $btnCancel.Enabled = $false; Show-Fatal '发送' $_ }
    })
    $btnCancel.Add_Click({
        try {
            $script:stopping = $true
            try { $script:client.CancelPendingRequests() } catch { }
            $lblChat.Text = '已停止'
        } catch { }
    })
    $script:timer.Add_Tick({
        try {
            $task = $script:task
            if ($null -eq $task) { $script:timer.Stop(); return }
            if (-not $task.IsCompleted) { return }
            $script:timer.Stop()
            $result = $null; $errorText = ''; $cancelled = $false
            try { $result = $task.GetAwaiter().GetResult() }
            catch [System.Threading.Tasks.TaskCanceledException] { $cancelled = $true }
            catch [System.OperationCanceledException] { $cancelled = $true }
            catch { $errorText = $_.Exception.Message }
            if ($cancelled -or $script:stopping) {
                $lblChat.Text = '已停止'
            } elseif ($errorText -ne '') {
                $lblChat.Text = '出错：' + $errorText
                Append-Msg '系统' ('请求失败：' + $errorText) ([System.Drawing.Color]::FromArgb(170, 0, 0))
            } elseif ($null -ne $result) {
                try {
                    if (-not $result.IsSuccessStatusCode) {
                        $errBody = $result.Content.ReadAsStringAsync().GetAwaiter().GetResult()
                        Append-Msg '系统' ('HTTP ' + [int]$result.StatusCode + '：' + $errBody) ([System.Drawing.Color]::FromArgb(170, 0, 0))
                        $lblChat.Text = '请求失败'
                    } else {
                        $json = $result.Content.ReadAsStringAsync().GetAwaiter().GetResult() | ConvertFrom-Json
                        $msg = $json.choices[0].message
                        $reasoning = ''
                        if ($null -ne $msg.reasoning_content) { $reasoning = [string]$msg.reasoning_content }
                        $answer = [string]$msg.content
                        if ($reasoning -ne '') { Append-Msg '思考过程' $reasoning ([System.Drawing.Color]::FromArgb(130, 130, 130)) }
                        $script:lastAnswer = $answer
                        Append-Msg '助手' $answer ([System.Drawing.Color]::FromArgb(20, 20, 20))
                        $tokens = 0
                        if ($null -ne $json.usage) { $tokens = [int]$json.usage.completion_tokens }
                        $elapsed = [math]::Round(((Get-Date) - $script:startTime).TotalSeconds, 1)
                        $tps = 0; if ($elapsed -gt 0 -and $tokens -gt 0) { $tps = [math]::Round($tokens / $elapsed, 1) }
                        $lblChat.Text = '完成  用时 ' + $elapsed + 's  输出 ' + $tokens + ' tokens  (' + $tps + ' tok/s)'
                        if ($answer -ne '') { [void]$script:msgs.Add([pscustomobject]@{ role = 'assistant'; content = $answer }) }
                    }
                } catch { $lblChat.Text = '解析回复失败'; Show-Fatal '解析回复' $_ }
            }
            $script:task = $null
        } catch { Show-Fatal '处理回复' $_ }
        finally {
            $script:stopping = $false
            $script:busy = $false
            $btnSend.Enabled = $true; $btnCancel.Enabled = $false
            try { $script:elapsed = '' } catch { }
        }
    })
    # ---- 启动/停止提示 ----
    $script:elapsed = ''
    # ---- 自启动开关 ----
    function Test-Autostart {
        $lnk = Join-Path ([Environment]::GetFolderPath('Startup')) 'llama.cpp 启动服务.lnk'
        return (Test-Path -LiteralPath $lnk)
    }
    function Set-Autostart([bool]$on) {
        $lnkPath = Join-Path ([Environment]::GetFolderPath('Startup')) 'llama.cpp 启动服务.lnk'
        if (-not $on) { if (Test-Path -LiteralPath $lnkPath) { Remove-Item -LiteralPath $lnkPath -Force }; return }
        $sh = New-Object -ComObject WScript.Shell
        $s = $sh.CreateShortcut($lnkPath)
        $s.TargetPath = (Join-Path $env:SystemRoot 'System32\wscript.exe')
        $s.Arguments = '"' + (Join-Path $script:root '启动控制台.vbs') + '"'
        $s.WorkingDirectory = $script:root
        $iconExe = [string]$script:cfg['engineExe']
        if ([string]::IsNullOrWhiteSpace($iconExe) -or -not (Test-Path -LiteralPath $iconExe)) { $iconExe = Join-Path $script:root 'llama-server.exe' }
        $s.IconLocation = $iconExe + ',0'
        $s.Save()
    }
    Update-Status
    if (Test-EngineRunning) {
        try {
            $diskCfg = Load-Config
            $script:startedSignature = Get-ConfigSignature $diskCfg
            $script:loadedModel = [string]$diskCfg.model
        } catch { }
    }
    $lblChat.Text = '就绪'
    # ---- 右键「恢复默认值」 ----
    foreach ($rk in @($script:ui.Keys)) {
        $rc = $script:ui[$rk]
        if ($null -eq $rc) { continue }
        if (-not ($rc -is [System.Windows.Forms.Control])) { continue }
        if (-not $script:DefaultConfig.Contains([string]$rk)) { continue }
        $cm = New-Object System.Windows.Forms.ContextMenuStrip
        $mi = $cm.Items.Add('恢复默认值')
        $mi.Tag = [string]$rk
        $mi.add_Click({ param($snd, $evt) Reset-Control ([string]$snd.Tag) })
        if ($script:rowDefs.ContainsKey([string]$rk)) {
            [void]$cm.Items.Add((New-Object System.Windows.Forms.ToolStripSeparator))
            $miUp = $cm.Items.Add('上移')
            $miUp.Tag = [string]$rk
            $miUp.add_Click({ param($snd, $evt) Move-Row ([string]$snd.Tag) -1 })
            $miDn = $cm.Items.Add('下移')
            $miDn.Tag = [string]$rk
            $miDn.add_Click({ param($snd, $evt) Move-Row ([string]$snd.Tag) 1 })
            $cm.Add_Opening({
                param($snd, $evt)
                $k = [string]$snd.Items[0].Tag
                $ix = $script:order.IndexOf($k)
                foreach ($it in $snd.Items) {
                    if ($it -is [System.Windows.Forms.ToolStripMenuItem]) {
                        if ($it.Text -eq '上移') { $it.Enabled = ($ix -gt 0) }
                        elseif ($it.Text -eq '下移') { $it.Enabled = ($ix -ge 0 -and $ix -lt ($script:order.Count - 1)) }
                    }
                }
            })
        }
        $rc.ContextMenuStrip = $cm
    }

    Apply-SavedLayoutOrder
    Update-EffortState ([string]$script:cfg['template'])
    $tabs.SelectedIndex = [Math]::Max(0, [Math]::Min(1, $TabIndex))
    # 隐藏控制台窗口并显示窗体
    $hConsole = [Win32.Api]::GetConsoleWindow()
    if ($hConsole -ne [IntPtr]::Zero) { [void][Win32.Api]::ShowWindow($hConsole, 0) }
    if ($AutoSend -ne '') { $f.Add_Shown({ $tabs.SelectedIndex = 1; $inputBox.Text = $AutoSend; $btnSend.PerformClick() }) }
    $f.Show()
    [void][Win32.Api]::ShowWindow($f.Handle, 5)
    [void][Win32.Api]::SetForegroundWindow($f.Handle)
    [System.Windows.Forms.Application]::Run($f)
}
catch {
    $script:fatal = $_
    try { Write-UiLog ('致命错误: ' + $_.Exception.ToString()) } catch { }
    try { Add-Type -AssemblyName System.Windows.Forms } catch { }
    try { Add-Type -AssemblyName System.Drawing } catch { }
    if ($SelfTest -or $ChatTest) { Write-Output ('ERROR: ' + $_.Exception.ToString()); Write-Output ($_.InvocationInfo.PositionMessage); exit 1 }
    try { [void][System.Windows.Forms.MessageBox]::Show(('脚本运行出错：' + [Environment]::NewLine + $_.Exception.Message + [Environment]::NewLine + $_.InvocationInfo.PositionMessage), 'llama.cpp 控制台', 'OK', 'Error') } catch { Write-Output $_.Exception.Message }
    exit 1
}
