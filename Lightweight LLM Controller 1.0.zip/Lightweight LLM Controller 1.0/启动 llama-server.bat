@echo off
cd /d "%~dp0"
echo Starting llama-server from settings.json ...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0autostart.ps1"
echo.
echo Server is starting in the background (log: server.log).
echo To stop it: use the console (Stop) or kill llama-server.exe.
timeout /t 3 >nul
