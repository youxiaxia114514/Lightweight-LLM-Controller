﻿$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$root = $scriptDir
$settingsPath = Join-Path $root 'settings.json'
$serverExe = Join-Path $root 'llama-server.exe'

if (-not (Test-Path -LiteralPath $settingsPath)) { exit 0 }

$c = Get-Content $settingsPath -Raw -Encoding UTF8 | ConvertFrom-Json

$engineExe = ''
if ($null -ne $c.PSObject.Properties['engineExe']) { $engineExe = [string]$c.engineExe }
if ($engineExe -eq '' -or -not (Test-Path -LiteralPath $engineExe)) {
    $localExe = Join-Path $scriptDir 'llama-server.exe'
    if (Test-Path -LiteralPath $localExe) { $engineExe = $localExe } else {
        Add-Content -LiteralPath (Join-Path $scriptDir 'console.log') -Value ('[{0}] 开机自启跳过：engineExe 无效，脚本目录也没有 llama-server.exe' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')) -Encoding UTF8
        exit 0
    }
}

$serverExe = $engineExe
$root = [IO.Path]::GetDirectoryName($engineExe)
if ([string]::IsNullOrWhiteSpace($root)) { $root = $scriptDir }

$procName = [IO.Path]::GetFileNameWithoutExtension($engineExe)
if ([string]::IsNullOrWhiteSpace($procName)) { $procName = 'llama-server' }
if (@(Get-Process -Name $procName -ErrorAction SilentlyContinue).Count -gt 0) { exit 0 }

# 合并 model_configs 中当前模型的专属参数（engineExe / port 属全局，不合并）
$perModelKeys = @('ctx','ngl','kv','threads','parallel','batch','ubatch','nPredict','seed',
  'temp','topP','topK','minP','repeatPen','flash','kvUnified','template','kvOffload',
  'mlock','mmap','threadsBatch','prio','noWarmup','contBatch','reasoningBudget',
  'systemPrompt','extra','effort')
$mcProp = $c.PSObject.Properties['model_configs']
if ($null -ne $mcProp -and $null -ne $mcProp.Value) {
    $blockProp = $mcProp.Value.PSObject.Properties[[string]$c.model]
    if ($null -ne $blockProp) {
        foreach ($k in $perModelKeys) {
            $p = $blockProp.Value.PSObject.Properties[$k]
            if ($null -ne $p -and $null -ne $p.Value) {
                $c | Add-Member -NotePropertyName $k -NotePropertyValue $p.Value -Force
            }
        }
    }
}

function Split-ArgsLine($line) {
    $rx = '"[^"]*"|''[^'']*''|\S+'
    $out = @()
    foreach ($m in [regex]::Matches("$line", $rx)) {
        $v = $m.Value
        if ($v.Length -ge 2) {
            $h = $v.Substring(0, 1); $t = $v.Substring($v.Length - 1, 1)
            if (($h -eq '"' -and $t -eq '"') -or ($h -eq "'" -and $t -eq "'")) { $v = $v.Substring(1, $v.Length - 2) }
        }
        if ($v -ne '') { $out += $v }
    }
    return $out
}

function Q([string]$s) {
    $v = [string]$s
    if ($v -eq '') { return '' }
    if ($v.Contains('"')) { $v = $v -replace '"', '\"' }
    if ($v -match '\s') { return '"' + $v + '"' }
    return $v
}
$hostIp = '127.0.0.1'
if ($c.allowLanAccess) { $hostIp = '0.0.0.0' }
$a = @('--model', (Q "$($c.model)"), '--host', $hostIp, '--port', "$($c.port)",
       '--ctx-size', "$($c.ctx)", '--n-gpu-layers', "$($c.ngl)",
       '--cache-type-k', "$($c.kv)", '--cache-type-v', "$($c.kv)",
       '--threads', "$($c.threads)", '--parallel', "$($c.parallel)",
       '--batch-size', "$($c.batch)", '--ubatch-size', "$($c.ubatch)",
       '--n-predict', "$($c.nPredict)", '--seed', "$($c.seed)",
       '--temp', "$($c.temp)", '--top-p', "$($c.topP)", '--top-k', "$($c.topK)",
       '--min-p', "$($c.minP)", '--repeat-penalty', "$($c.repeatPen)",
       '--jinja', '--alias', (Q ([IO.Path]::GetFileNameWithoutExtension("$($c.model)"))))

if ("$($c.flash)" -eq 'on') { $a += @('--flash-attn', 'on') }
elseif ("$($c.flash)" -eq 'off') { $a += @('--flash-attn', 'off') }
if ($c.kvUnified) { $a += '--kv-unified' } else { $a += '--no-kv-unified' }
$tplPath = [string]$c.template
if (-not [string]::IsNullOrWhiteSpace($tplPath) -and -not (Test-Path -LiteralPath $tplPath)) {
    $alt = Join-Path $scriptDir ([IO.Path]::GetFileName($tplPath))
    if (Test-Path -LiteralPath $alt) {
        $tplPath = $alt
    } else {
        Add-Content -LiteralPath (Join-Path $scriptDir 'console.log') -Value ('[{0}] 警告: 未找到思考模板 {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $tplPath) -Encoding UTF8
        $tplPath = ''
    }
}
if (-not [string]::IsNullOrWhiteSpace($tplPath) -and (Test-Path -LiteralPath $tplPath)) {
    $a += @('--chat-template-file', (Q $tplPath))
}
$mpFile = Get-ChildItem -LiteralPath (Split-Path -Parent "$($c.model)") -Filter 'mmproj*.gguf' -ErrorAction SilentlyContinue | Select-Object -First 1
if ($mpFile) { $a += @('--mmproj', (Q $mpFile.FullName)) }

if ($c.kvOffload -eq $false) { $a += '--no-kv-offload' }
# 新版 llama.cpp（b12377 起）删除 --mmap/--no-mmap/--mlock，改为 --load-mode MODE
# MODE 取值: auto / none / mmap / mlock / mmap+mlock / dio
if ($c.mmap -eq $false) {
    if ($c.mlock) { $a += @('--load-mode', 'mlock') } else { $a += @('--load-mode', 'none') }
} elseif ($c.mlock) {
    $a += @('--load-mode', 'mmap+mlock')
}
if ([int]$c.threadsBatch -gt 0) { $a += @('--threads-batch', "$($c.threadsBatch)") }
if ([int]$c.prio -gt 0) { $a += @('--prio', "$($c.prio)") }
if ($c.noWarmup) { $a += '--no-warmup' }
if ($c.contBatch -eq $false) { $a += '--no-cont-batching' }
if ($c.useMoe -and [int]$c.nCpuMoe -gt 0) { $a += @('--n-cpu-moe', [string][int]$c.nCpuMoe) }
$kwList = @()
if ($null -ne $c.effort_keywords) { $kwList = @($c.effort_keywords) }
$mName = [IO.Path]::GetFileNameWithoutExtension([string]$c.model).ToLowerInvariant()
$effAllowed = $false
if ($mName.Contains('deepseek') -or $mName.Contains('r1')) { $effAllowed = $false } else { foreach ($kw in $kwList) { $kwT = ([string]$kw).Trim(); if ($kwT -eq "") { continue }; if ($mName.Contains($kwT.ToLowerInvariant())) { $effAllowed = $true; break } } }
if ($effAllowed) { $a += @('--reasoning-budget', '4096') }
if ("$($c.apiKey)".Trim() -ne '') { $a += @('--api-key', (Q "$($c.apiKey)")) }
if ($c.verbose) { $a += '--verbose' }
if ($c.metrics) { $a += '--metrics' }
if ($c.slots) { $a += '--slots' }
foreach ($row in @($c.extra)) {
    if ($row -is [string]) { $k = $row.Trim(); $v = "" } else { $k = [string]$row.key; $v = [string]$row.value }
    if ($k -eq "") { continue }
    if (-not $k.StartsWith("--")) { $k = "--" + $k }
    if ($v.Trim() -eq "") { $a += $k } else { $a += @($k, (Q $v.Trim())) }
}

Start-Process -FilePath $serverExe -ArgumentList $a -WorkingDirectory $root -WindowStyle Minimized `
    -RedirectStandardOutput (Join-Path $scriptDir 'server.log') -RedirectStandardError (Join-Path $scriptDir 'server.err.log')
